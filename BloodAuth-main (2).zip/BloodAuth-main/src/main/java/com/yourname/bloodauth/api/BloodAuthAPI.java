package com.yourname.bloodauth.api;

import com.yourname.bloodauth.BloodAuth;
import com.yourname.bloodauth.model.LoginState;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public final class BloodAuthAPI {

    private static BloodAuthAPI instance;
    private final BloodAuth plugin;

    public BloodAuthAPI(BloodAuth plugin) {
        this.plugin = plugin;
        instance    = this;
    }

    @Nullable
    public static BloodAuthAPI getInstance() {
        return instance;
    }

    public static void invalidate() {  // <-- was package-private, now public
        instance = null;
    }

    // State queries (any thread)
    public boolean isAuthenticated(UUID uuid) {
        return plugin.getSessionManager().isAuthenticated(uuid);
    }

    public boolean isAwaiting2FA(UUID uuid) {
        return plugin.getSessionManager().isAwaiting2FA(uuid);
    }

    public LoginState getLoginState(UUID uuid) {
        var session = plugin.getSessionManager().getSession(uuid);
        return session == null ? LoginState.UNAUTHENTICATED : session.getState();
    }

    public CompletableFuture<Boolean> isRegistered(UUID uuid) {
        return plugin.getDatabaseManager().getDatabase().isRegistered(uuid);
    }

    public CompletableFuture<Boolean> has2FAEnabled(UUID uuid) {
        return plugin.getDatabaseManager().getDatabase()
                .getPlayer(uuid)
                .thenApply(opt -> opt.map(
                        com.yourname.bloodauth.model.PlayerData::isTotpEnabled).orElse(false));
    }

    // Mutating methods (main thread only)
    public void forceAuthenticate(org.bukkit.entity.Player player) {
        ensureMainThread("forceAuthenticate");
        plugin.getSessionManager().authenticate(player);
    }

    public void forceDeauthenticate(org.bukkit.entity.Player player) {
        ensureMainThread("forceDeauthenticate");
        plugin.getSessionManager().deauthenticate(player, false);
        plugin.getDatabaseManager().getDatabase().deleteSession(player.getUniqueId());
        plugin.getSessionManager().applyAuthRestrictions(player);
    }

    private void ensureMainThread(String method) {
        if (!plugin.getServer().isPrimaryThread()) {
            throw new IllegalStateException(
                    "BloodAuthAPI#" + method + "() must be called from the main server thread.");
        }
    }
}
