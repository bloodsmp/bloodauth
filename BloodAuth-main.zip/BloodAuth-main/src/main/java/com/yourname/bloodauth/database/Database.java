package com.yourname.bloodauth.database;

import com.yourname.bloodauth.model.PlayerData;
import com.yourname.bloodauth.model.PersistentSession;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public interface Database {
    void connect() throws Exception;
    void disconnect();

    CompletableFuture<Optional<PlayerData>> getPlayer(UUID uuid);
    CompletableFuture<Optional<PlayerData>> getPlayerByName(String username);
    CompletableFuture<Void> savePlayer(PlayerData data);
    CompletableFuture<Void> deletePlayer(UUID uuid);

    CompletableFuture<Optional<PersistentSession>> getSession(UUID uuid);
    CompletableFuture<Void> saveSession(PersistentSession session);
    CompletableFuture<Void> deleteSession(UUID uuid);

    CompletableFuture<Boolean> isRegistered(UUID uuid);
    CompletableFuture<List<UUID>> getInactivePlayers(long cutoffTimestamp);
}
