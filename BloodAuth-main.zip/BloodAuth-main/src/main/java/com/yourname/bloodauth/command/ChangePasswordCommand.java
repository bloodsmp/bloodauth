package com.yourname.bloodauth.command;

import com.yourname.bloodauth.BloodAuth;
import com.yourname.bloodauth.model.AuthEvent;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;
import java.util.logging.Level;

public final class ChangePasswordCommand implements CommandExecutor {

    private final BloodAuth plugin;

    public ChangePasswordCommand(BloodAuth plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // Guard: player only
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessagesManager().get("general.not-player"));
            return true;
        }

        UUID uuid = player.getUniqueId();

        // Guard: must be authenticated
        if (!plugin.getSessionManager().isAuthenticated(uuid)) {
            player.sendMessage(plugin.getMessagesManager().get("general.not-authenticated"));
            return true;
        }

        // Guard: rate limit
        if (!plugin.getRateLimiter().tryConsume(uuid)) {
            player.sendMessage(plugin.getMessagesManager().get("general.rate-limited",
                    "seconds", String.valueOf(plugin.getRateLimiter().remainingSeconds(uuid))));
            return true;
        }

        // Guard: argument count
        if (args.length != 2) {
            player.sendMessage(plugin.getMessagesManager().get("changepassword.usage"));
            return true;
        }

        String oldPassword = args[0];
        String newPassword = args[1];

        // Guard: same password
        if (oldPassword.equals(newPassword)) {
            player.sendMessage(plugin.getMessagesManager().get("changepassword.same-password"));
            return true;
        }

        int min = plugin.getConfigManager().getPasswordMinLength();
        int max = plugin.getConfigManager().getPasswordMaxLength();

        // Guard: new password too short
        if (newPassword.length() < min) {
            player.sendMessage(plugin.getMessagesManager().get("changepassword.password-too-short",
                    "min", String.valueOf(min)));
            return true;
        }

        // Guard: new password too long
        if (newPassword.length() > max) {
            player.sendMessage(plugin.getMessagesManager().get("changepassword.password-too-long",
                    "max", String.valueOf(max)));
            return true;
        }

        String ip = player.getAddress() != null
                ? player.getAddress().getAddress().getHostAddress()
                : "unknown";

        // Async: load, verify old, hash new, save
        plugin.getDatabaseManager().getDatabase()
                .getPlayer(uuid)
                .thenAccept(optData -> {
                    if (!player.isOnline()) return;

                    if (optData.isEmpty()) {
                        plugin.getServer().getScheduler().runTask(plugin, () ->
                                player.sendMessage(plugin.getMessagesManager()
                                        .get("login.not-registered")));
                        return;
                    }

                    var data = optData.get();

                    if (!plugin.getPasswordManager().verify(oldPassword, data.getPasswordHash())) {
                        plugin.getServer().getScheduler().runTask(plugin, () ->
                                player.sendMessage(plugin.getMessagesManager()
                                        .get("changepassword.wrong-old-password")));
                        return;
                    }

                    String newHash = plugin.getPasswordManager().hash(newPassword);
                    data.setPasswordHash(newHash);

                    plugin.getDatabaseManager().getDatabase()
                            .savePlayer(data)
                            .thenRun(() -> {
                                if (!player.isOnline()) return;
                                plugin.getServer().getScheduler().runTask(plugin, () -> {
                                    player.sendMessage(plugin.getMessagesManager()
                                            .get("changepassword.success"));
                                    plugin.getAuthLogger().logAuth(player.getName(), ip,
                                            AuthEvent.PASSWORD_CHANGED, "Password changed");
                                    plugin.getDiscordWebhook().sendPasswordChanged(
                                            player.getName(), uuid, ip);
                                });
                            })
                            .exceptionally(ex -> {
                                plugin.getLogger().log(Level.SEVERE,
                                        "Error saving password change for " + player.getName(), ex);
                                return null;
                            });
                })
                .exceptionally(ex -> {
                    plugin.getLogger().log(Level.SEVERE,
                            "Error in changepassword for " + player.getName(), ex);
                    return null;
                });

        return true;
    }
}
