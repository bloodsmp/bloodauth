package com.yourname.bloodauth.model;

import org.bukkit.scheduler.BukkitTask;

import java.util.UUID;

public final class PlayerSession {

    private final UUID uuid;
    private final String ip;
    private final long joinTime;
    private LoginState state;
    private int failedAttempts;
    private BukkitTask timeoutTask;

    public PlayerSession(UUID uuid, String ip) {
        this.uuid           = uuid;
        this.ip             = ip;
        this.joinTime       = System.currentTimeMillis();
        this.state          = LoginState.UNAUTHENTICATED;
        this.failedAttempts = 0;
    }

    public void cancelTimeoutTask() {
        if (timeoutTask != null) {
            timeoutTask.cancel();
            timeoutTask = null;
        }
    }

    public void incrementFailedAttempts() {
        failedAttempts++;
    }

    public boolean isAuthenticated() {
        return state == LoginState.AUTHENTICATED;
    }

    public boolean isAwaiting2FA() {
        return state == LoginState.AWAITING_2FA;
    }

    // Getters
    public UUID        getUuid()           { return uuid; }
    public String      getIp()             { return ip; }
    public long        getJoinTime()       { return joinTime; }
    public LoginState  getState()          { return state; }
    public int         getFailedAttempts() { return failedAttempts; }
    public BukkitTask  getTimeoutTask()    { return timeoutTask; }

    // Setters
    public void setState(LoginState state)       { this.state = state; }
    public void setFailedAttempts(int n)         { this.failedAttempts = n; }
    public void setTimeoutTask(BukkitTask task)  { this.timeoutTask = task; }
}
