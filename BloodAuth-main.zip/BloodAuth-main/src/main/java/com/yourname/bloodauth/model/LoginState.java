package com.yourname.bloodauth.model;

public enum LoginState {
    UNAUTHENTICATED,
    AWAITING_2FA,
    AUTHENTICATED
}
