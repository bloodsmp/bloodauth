package com.yourname.bloodauth.command;

import com.yourname.bloodauth.BloodAuth;
import com.yourname.bloodauth.model.AuthEvent;
import com.yourname.bloodauth.model.PlayerData;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;
import java.util.logging.Level;

public final class LoginCommand implements CommandExecutor {

    private final BloodAuth plugin;

    public LoginCommand(BloodAuth plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // Guard: player only
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessagesManager().get("general.not-player"));
            return true;
        }

        UUID uuid = player.getUniqueId();

        // Guard: already authenticated
        if (plugin.getSessionManager().isAuthenticated(uuid)) {
            player.sendMessage(plugin.getMessagesManager().get("login.already-authenticated"));
            return true;
        }

        // Guard: rate limit
        if (!plugin.getRateLimiter().tryConsume(uuid)) {
            player.sendMessage(plugin.getMessagesManager().get("general.rate-limited",
                    "seconds", String.valueOf(plugin.getRateLimiter().remainingSeconds(uuid))));
            return true;
        }

        // Guard: argument count
        if (args.length != 1) {
            player.sendMessage(plugin.getMessagesManager().get("login.usage"));
            return true;
        }

        String password = args[0];
        String ip = player.getAddress() != null
                ? player.getAddress().getAddress().getHostAddress()
                : "unknown";

        // Async flow
        plugin.getDatabaseManager().getDatabase()
                .getPlayer(uuid)
                .thenAccept(optData -> {
                    if (!player.isOnline()) return;

                    if (optData.isEmpty()) {
                        plugin.getServer().getScheduler().runTask(plugin, () ->
                                player.sendMessage(plugin.getMessagesManager()
                                        .get("login.not-registered")));
                        return;
                    }

                    PlayerData data = optData.get();

                    // Check temp-ban
                    if (data.isCurrentlyTempBanned()) {
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        String expiry = sdf.format(new Date(data.getTempBanExpiry()));
                        plugin.getServer().getScheduler().runTask(plugin, () ->
                                player.sendMessage(plugin.getMessagesManager()
                                        .get("ban.temp-banned-chat", "expiry", expiry)));
                        return;
                    }

                    // Verify password
                    boolean correct = plugin.getPasswordManager().verify(password, data.getPasswordHash());
                    int maxAttempts = plugin.getConfigManager().getMaxLoginAttempts();

                    if (!correct) {
                        data.incrementFailedAttempts();
                        int attempts = data.getFailedAttempts();

                        plugin.getAuthLogger().logAuth(player.getName(), ip,
                                AuthEvent.LOGIN_FAILED,
                                "Failed attempt " + attempts + "/" + maxAttempts);
                        plugin.getDiscordWebhook().sendLoginFailed(
                                player.getName(), uuid, ip, attempts, maxAttempts);

                        if (attempts >= maxAttempts) {
                            // Apply temp-ban
                            long banMillis = (long) plugin.getConfigManager().getTempBanDuration() * 60_000;
                            data.setTempBanExpiry(System.currentTimeMillis() + banMillis);

                            plugin.getDatabaseManager().getDatabase().savePlayer(data);
                            plugin.getAuthLogger().logAuth(player.getName(), ip,
                                    AuthEvent.ACCOUNT_LOCKED, "Temp-banned for "
                                    + plugin.getConfigManager().getTempBanDuration() + " min");
                            plugin.getDiscordWebhook().sendAccountLocked(player.getName(), uuid, ip);

                            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                            String expiry = sdf.format(new Date(data.getTempBanExpiry()));

                            plugin.getServer().getScheduler().runTask(plugin, () -> {
                                if (player.isOnline()) {
                                    player.kickPlayer(ChatColor.translateAlternateColorCodes('&',
                                            plugin.getMessagesManager().get("ban.temp-banned",
                                                    "expiry", expiry)));
                                }
                            });
                        } else {
                            plugin.getDatabaseManager().getDatabase().savePlayer(data);
                            plugin.getServer().getScheduler().runTask(plugin, () ->
                                    player.sendMessage(plugin.getMessagesManager()
                                            .get("login.wrong-password",
                                                    "attempts", String.valueOf(attempts),
                                                    "max", String.valueOf(maxAttempts))));
                        }
                        return;
                    }

                    // Correct password — clear failed attempts
                    data.setFailedAttempts(0);

                    // Check if 2FA is required
                    boolean bypass2FA = player.hasPermission("bloodauth.bypass2fa");
                    if (data.isTotpEnabled() && !bypass2FA) {
                        plugin.getDatabaseManager().getDatabase().savePlayer(data);
                        plugin.getServer().getScheduler().runTask(plugin, () -> {
                            if (!player.isOnline()) return;
                            plugin.getSessionManager().setAwaiting2FA(uuid);
                            player.sendMessage(plugin.getMessagesManager().get("totp.usage"));
                        });
                        return;
                    }

                    // Finalize login
                    finalizeLogin(player, data, ip);
                })
                .exceptionally(ex -> {
                    plugin.getLogger().log(Level.SEVERE,
                            "Error during login for " + player.getName(), ex);
                    return null;
                });

        return true;
    }

    /**
     * Updates last-login metadata, persists player data, then authenticates on main thread.
     */
    void finalizeLogin(Player player, PlayerData data, String ip) {
        UUID uuid = player.getUniqueId();
        data.setLastLogin(System.currentTimeMillis());
        data.setLastIp(ip);

        plugin.getDatabaseManager().getDatabase()
                .savePlayer(data)
                .thenRun(() -> {
                    if (!player.isOnline()) return;
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        plugin.getSessionManager().authenticate(player);
                        player.sendMessage(plugin.getMessagesManager().get("login.success"));
                        plugin.getAuthLogger().logAuth(player.getName(), ip,
                                AuthEvent.LOGIN_SUCCESS, "Password login");
                        plugin.getDiscordWebhook().sendLoginSuccess(
                                player.getName(), uuid, ip,
                                data.getLastCountry() != null ? data.getLastCountry() : "");
                    });
                })
                .exceptionally(ex -> {
                    plugin.getLogger().log(Level.SEVERE,
                            "Error finalizing login for " + player.getName(), ex);
                    return null;
                });
    }
}
