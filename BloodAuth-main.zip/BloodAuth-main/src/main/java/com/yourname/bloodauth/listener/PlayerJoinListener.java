package com.yourname.bloodauth.listener;

import com.yourname.bloodauth.BloodAuth;
import com.yourname.bloodauth.model.AuthEvent;
import com.yourname.bloodauth.model.PlayerData;
import com.yourname.bloodauth.task.LoginTimeoutTask;
import com.yourname.bloodauth.util.CountryUtil;
import com.yourname.bloodauth.util.IPUtil;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;
import java.util.logging.Level;

public final class PlayerJoinListener implements Listener {

    private final BloodAuth plugin;

    public PlayerJoinListener(BloodAuth plugin) {
        this.plugin = plugin;
    }

    // -------------------------------------------------------------------------
    // Login event — temp-ban check (async DB, disallow on main)
    // -------------------------------------------------------------------------

    @EventHandler(priority = EventPriority.HIGH)
    public void onLogin(PlayerLoginEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();

        // Block if temp-banned (synchronous for PlayerLoginEvent allowance)
        // We use a synchronous get here; the DB pool has threads available.
        try {
            var optData = plugin.getDatabaseManager().getDatabase()
                    .getPlayer(uuid).get(2, java.util.concurrent.TimeUnit.SECONDS);

            if (optData.isPresent()) {
                PlayerData data = optData.get();
                if (data.isCurrentlyTempBanned()) {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    String expiry = sdf.format(new Date(data.getTempBanExpiry()));
                    String msg = plugin.getMessagesManager().get("ban.temp-banned",
                            "expiry", expiry);
                    event.disallow(PlayerLoginEvent.Result.KICK_BANNED,
                            ChatColor.translateAlternateColorCodes('&', msg));
                }
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Error during login ban check for " + uuid, e);
        }
    }

    // -------------------------------------------------------------------------
    // Join event — session setup, persistent session check, auth prompt
    // -------------------------------------------------------------------------

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        UUID   uuid   = player.getUniqueId();
        String ip     = player.getAddress() != null
                ? player.getAddress().getAddress().getHostAddress()
                : "unknown";

        // Create in-memory session and apply blindness / hide from others
        plugin.getSessionManager().createSession(uuid, ip);
        plugin.getSessionManager().applyAuthRestrictions(player);

        // Async: load player account then decide what to do
        plugin.getDatabaseManager().getDatabase()
                .getPlayer(uuid)
                .thenAccept(optData -> {
                    if (!player.isOnline()) return;

                    if (optData.isPresent()) {
                        PlayerData data = optData.get();

                        // Sync username if the player renamed
                        if (!data.getUsername().equalsIgnoreCase(player.getName())) {
                            data.setUsername(player.getName());
                            plugin.getDatabaseManager().getDatabase().savePlayer(data);
                        }

                        // Attempt to resume a persistent session
                        plugin.getSessionManager()
                                .checkPersistentSession(player, ip)
                                .thenAccept(resumed -> {
                                    if (!resumed) {
                                        plugin.getServer().getScheduler().runTask(plugin,
                                                () -> schedulePendingAuth(player, ip, data));
                                    }
                                });
                    } else {
                        // Not registered
                        plugin.getServer().getScheduler().runTask(plugin,
                                () -> schedulePendingAuth(player, ip, null));
                    }
                })
                .exceptionally(ex -> {
                    plugin.getLogger().log(Level.SEVERE,
                            "Error loading player data for " + player.getName(), ex);
                    return null;
                });
    }

    // -------------------------------------------------------------------------
    // Schedule auth prompt + timeout + GeoIP + VPN
    // -------------------------------------------------------------------------

    /**
     * Called on the main thread after the account load resolves.
     *
     * @param data null if the player is not registered
     */
    private void schedulePendingAuth(Player player, String ip, PlayerData data) {
        if (!player.isOnline()) return;

        boolean hasAccount = data != null;

        // Send the appropriate prompt
        if (hasAccount) {
            player.sendMessage(plugin.getMessagesManager().get("general.please-login"));
        } else {
            player.sendMessage(plugin.getMessagesManager().get("general.please-register"));
        }

        // Schedule login timeout
        int timeout = plugin.getConfigManager().getSessionTimeout();
        if (timeout > 0) {
            var session = plugin.getSessionManager().getSession(player.getUniqueId());
            if (session != null) {
                LoginTimeoutTask task = new LoginTimeoutTask(plugin, player.getUniqueId());
                var bukkit = task.runTaskLater(plugin, 20L * timeout);
                session.setTimeoutTask(bukkit);
            }
        }

        // GeoIP check (async)
        if (plugin.getGeoIPManager().isAvailable()) {
            plugin.getGeoIPManager()
                    .lookupCountry(ip)
                    .thenAccept(code -> handleGeoIPResult(player, ip, code, data))
                    .exceptionally(ex -> {
                        plugin.getLogger().log(Level.WARNING,
                                "GeoIP error for " + player.getName(), ex);
                        return null;
                    });
        }

        // VPN check (async)
        if (plugin.getConfigManager().isVpnCheckEnabled()) {
            String apiUrl   = plugin.getConfigManager().getVpnApiUrl();
            String jsonField = plugin.getConfigManager().getVpnJsonField();
            boolean doBlock = plugin.getConfigManager().isVpnBlock();

            IPUtil.isVPN(ip, apiUrl, jsonField).thenAccept(isVpn -> {
                if (!isVpn || !player.isOnline()) return;

                plugin.getAuthLogger().logAuth(player.getName(), ip,
                        AuthEvent.VPN_DETECTED, "VPN/proxy detected");

                if (doBlock) {
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        if (player.isOnline()) {
                            player.kickPlayer(ChatColor.translateAlternateColorCodes('&',
                                    plugin.getMessagesManager().get("vpn.detected")));
                        }
                    });
                    plugin.getDiscordWebhook().sendVPNDetected(
                            player.getName(), player.getUniqueId(), ip);
                }
            }).exceptionally(ex -> null);
        }
    }

    // -------------------------------------------------------------------------
    // GeoIP result handling
    // -------------------------------------------------------------------------

    private void handleGeoIPResult(Player player, String ip, String code, PlayerData data) {
        if (code == null || code.equalsIgnoreCase("LOCAL")) {
            plugin.getAuthLogger().logGeoIP(player.getName(), ip,
                    code == null ? "UNKNOWN" : code, "Skipped (local/unknown)");
            return;
        }

        plugin.getAuthLogger().logGeoIP(player.getName(), ip, code, "Resolved");

        // Country blocked?
        if (plugin.getGeoIPManager().isCountryBlocked(code)) {
            boolean hasBypass = player.hasPermission(
                    plugin.getConfigManager().getGeoIPBypassPermission());
            if (!hasBypass) {
                plugin.getAuthLogger().logGeoIP(player.getName(), ip, code, "BLOCKED");
                plugin.getDiscordWebhook().sendGeoIPBlocked(
                        player.getName(), player.getUniqueId(), ip, code);

                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    if (player.isOnline()) {
                        player.kickPlayer(ChatColor.translateAlternateColorCodes('&',
                                plugin.getMessagesManager().get("geoip.blocked",
                                        "country", CountryUtil.getFlagWithCode(code))));
                    }
                });
                return;
            }
        }

        // New country alert / kick
        if (data != null && data.getLastCountry() != null && !code.equals(data.getLastCountry())) {
            plugin.getAuthLogger().logGeoIP(player.getName(), ip, code,
                    "New country (was: " + data.getLastCountry() + ")");
            plugin.getDiscordWebhook().sendNewCountryLogin(
                    player.getName(), player.getUniqueId(), ip, data.getLastCountry(), code);

            if (plugin.getConfigManager().isNewCountryAlert()) {
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    if (player.isOnline()) {
                        player.sendMessage(plugin.getMessagesManager().get(
                                "geoip.new-country-alert",
                                "country", CountryUtil.getFlagWithCode(code)));
                    }
                });
            }

            if (plugin.getConfigManager().isNewCountryKick()) {
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    if (player.isOnline()) {
                        player.kickPlayer(ChatColor.translateAlternateColorCodes('&',
                                plugin.getMessagesManager().get("geoip.new-country-kick")));
                    }
                });
            }
        }
    }
}
