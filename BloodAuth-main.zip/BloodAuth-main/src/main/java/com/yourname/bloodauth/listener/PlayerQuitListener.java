package com.yourname.bloodauth.listener;

import com.yourname.bloodauth.BloodAuth;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public final class PlayerQuitListener implements Listener {

    private final BloodAuth plugin;

    public PlayerQuitListener(BloodAuth plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        var player = event.getPlayer();
        var uuid   = player.getUniqueId();

        if (plugin.getSessionManager().isAuthenticated(uuid)) {
            // Persist session so same-IP rejoin can skip login
            plugin.getSessionManager().deauthenticate(player, true);
        }

        plugin.getSessionManager().removeSession(uuid);
        plugin.getRateLimiter().remove(uuid);
    }
}
