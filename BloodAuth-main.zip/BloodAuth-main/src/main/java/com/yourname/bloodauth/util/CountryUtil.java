package com.yourname.bloodauth.util;

public final class CountryUtil {

    private CountryUtil() {}

    /**
     * Converts an ISO 3166-1 alpha-2 country code to its Unicode flag emoji.
     * Returns an empty string for null, blank, or "LOCAL".
     */
    public static String getFlag(String code) {
        if (code == null || code.isBlank() || code.equalsIgnoreCase("LOCAL")) return "";
        String upper = code.toUpperCase();
        if (upper.length() != 2) return "";
        int firstLetter  = upper.charAt(0) - 'A' + 0x1F1E6;
        int secondLetter = upper.charAt(1) - 'A' + 0x1F1E6;
        return new String(Character.toChars(firstLetter)) + new String(Character.toChars(secondLetter));
    }

    /**
     * Returns a string like "🇺🇸 US" combining the flag emoji and country code.
     * Returns the code alone for LOCAL or unknown codes.
     */
    public static String getFlagWithCode(String code) {
        if (code == null || code.isBlank()) return "Unknown";
        if (code.equalsIgnoreCase("LOCAL"))  return "LOCAL";
        String flag = getFlag(code);
        return flag.isEmpty() ? code.toUpperCase() : flag + " " + code.toUpperCase();
    }
}
