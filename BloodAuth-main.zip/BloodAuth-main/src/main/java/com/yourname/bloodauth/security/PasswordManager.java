package com.yourname.bloodauth.security;

import com.yourname.bloodauth.BloodAuth;
import org.mindrot.jbcrypt.BCrypt;

public final class PasswordManager {

    private final BloodAuth plugin;

    public PasswordManager(BloodAuth plugin) {
        this.plugin = plugin;
    }

    /**
     * Hashes a plaintext password using BCrypt with the configured cost factor.
     */
    public String hash(String plaintext) {
        int cost = plugin.getConfigManager().getBcryptCost();
        return BCrypt.hashpw(plaintext, BCrypt.gensalt(cost));
    }

    /**
     * Verifies a plaintext password against a stored BCrypt hash.
     * Returns false for null/empty inputs or malformed hashes.
     */
    public boolean verify(String plaintext, String hash) {
        if (plaintext == null || plaintext.isEmpty()) return false;
        if (hash == null || hash.isEmpty())           return false;
        try {
            return BCrypt.checkpw(plaintext, hash);
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
}
