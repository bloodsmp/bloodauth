package com.yourname.bloodauth.database;

import com.yourname.bloodauth.BloodAuth;

import java.util.logging.Level;

public final class DatabaseManager {

    private final BloodAuth plugin;
    private Database database;

    public DatabaseManager(BloodAuth plugin) {
        this.plugin = plugin;
    }

    public void initialize() throws Exception {
        String type = plugin.getConfigManager().getDatabaseType();
        database = switch (type.toLowerCase()) {
            case "mysql"  -> new MySQLDatabase(plugin);
            default       -> new SQLiteDatabase(plugin);
        };
        database.connect();
        plugin.getLogger().info("Connected to " + type.toUpperCase() + " database.");
    }

    public void shutdown() {
        if (database != null) {
            database.disconnect();
        }
    }

    public Database getDatabase() {
        if (database == null) {
            throw new IllegalStateException("DatabaseManager has not been initialized.");
        }
        return database;
    }
}
