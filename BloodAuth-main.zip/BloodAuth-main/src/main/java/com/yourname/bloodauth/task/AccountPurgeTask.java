package com.yourname.bloodauth.task;

import com.yourname.bloodauth.BloodAuth;

import java.util.logging.Level;

public final class AccountPurgeTask implements Runnable {

    private final BloodAuth plugin;

    public AccountPurgeTask(BloodAuth plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        int days = plugin.getConfigManager().getPurgeInactiveDays();
        if (days <= 0) return;

        long cutoff = System.currentTimeMillis() - ((long) days * 24 * 60 * 60 * 1000);
        plugin.getDatabaseManager().getDatabase()
                .getInactivePlayers(cutoff)
                .thenAccept(uuids -> {
                    if (uuids.isEmpty()) return;
                    plugin.getLogger().info("[Purge] Removing " + uuids.size()
                            + " inactive account(s) (inactive > " + days + " days).");
                    for (var uuid : uuids) {
                        plugin.getDatabaseManager().getDatabase().deletePlayer(uuid);
                        plugin.getDatabaseManager().getDatabase().deleteSession(uuid);
                    }
                })
                .exceptionally(ex -> {
                    plugin.getLogger().log(Level.WARNING, "[Purge] Error during account purge.", ex);
                    return null;
                });
    }
}
