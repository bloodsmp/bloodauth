package com.yourname.bloodauth.util;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;

public final class IPUtil {

    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .build();

    private IPUtil() {}

    /**
     * Masks the last two octets of an IPv4 address or the last two groups of an IPv6
     * address, replacing them with "***".
     */
    public static String maskIP(String ip) {
        if (ip == null || ip.isBlank()) return "***";
        if (ip.contains(":")) {
            // IPv6 — mask last two groups
            String[] parts = ip.split(":", -1);
            if (parts.length >= 2) {
                parts[parts.length - 1] = "***";
                parts[parts.length - 2] = "***";
            }
            return String.join(":", parts);
        } else {
            // IPv4 — mask last two octets
            String[] parts = ip.split("\\.", -1);
            if (parts.length == 4) {
                parts[2] = "***";
                parts[3] = "***";
            }
            return String.join(".", parts);
        }
    }

    /**
     * Asynchronously queries a VPN/proxy detection API.
     *
     * @param ip       the IP address to check
     * @param apiUrl   URL template with {ip} placeholder
     * @param jsonField dot-separated path to a boolean field in the JSON response
     * @return a future resolving to true if VPN/proxy is detected, false otherwise
     */
    public static CompletableFuture<Boolean> isVPN(String ip, String apiUrl, String jsonField) {
        String url = apiUrl.replace("{ip}", ip);
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(8))
                .GET()
                .build();

        return HTTP.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(response -> {
                    if (response.statusCode() != 200) return false;
                    return extractBooleanField(response.body(), jsonField);
                })
                .exceptionally(ex -> false);
    }

    /**
     * Extracts a boolean value from a dot-separated JSON path without an external library.
     * Works for simple flat and one-level nested JSON structures.
     */
    private static boolean extractBooleanField(String json, String dotPath) {
        String[] keys = dotPath.split("\\.");
        String current = json;
        for (String key : keys) {
            int keyIdx = current.indexOf("\"" + key + "\"");
            if (keyIdx < 0) return false;
            int colonIdx = current.indexOf(':', keyIdx + key.length() + 2);
            if (colonIdx < 0) return false;
            // Find the start of the value (skip whitespace)
            int valueStart = colonIdx + 1;
            while (valueStart < current.length() && Character.isWhitespace(current.charAt(valueStart))) {
                valueStart++;
            }
            // If next char is '{', narrow context into nested object
            if (current.charAt(valueStart) == '{') {
                int depth = 0;
                int end = valueStart;
                for (; end < current.length(); end++) {
                    if (current.charAt(end) == '{') depth++;
                    else if (current.charAt(end) == '}') { depth--; if (depth == 0) break; }
                }
                current = current.substring(valueStart, end + 1);
            } else {
                // It's a scalar — extract up to next comma or closing brace
                int valueEnd = valueStart;
                while (valueEnd < current.length()
                        && current.charAt(valueEnd) != ','
                        && current.charAt(valueEnd) != '}'
                        && current.charAt(valueEnd) != ']') {
                    valueEnd++;
                }
                String raw = current.substring(valueStart, valueEnd).trim().replace("\"", "");
                return Boolean.parseBoolean(raw);
            }
        }
        return false;
    }
}
