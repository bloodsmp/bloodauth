package com.yourname.bloodauth.security;

import com.yourname.bloodauth.BloodAuth;
import com.yourname.bloodauth.model.LoginState;
import com.yourname.bloodauth.model.PersistentSession;
import com.yourname.bloodauth.model.PlayerSession;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

public final class SessionManager {

    private final BloodAuth plugin;
    private final ConcurrentHashMap<UUID, PlayerSession> sessions = new ConcurrentHashMap<>();

    public SessionManager(BloodAuth plugin) {
        this.plugin = plugin;
    }

    // -------------------------------------------------------------------------
    // Session lifecycle
    // -------------------------------------------------------------------------

    public PlayerSession createSession(UUID uuid, String ip) {
        PlayerSession session = new PlayerSession(uuid, ip);
        sessions.put(uuid, session);
        return session;
    }

    public PlayerSession getSession(UUID uuid) {
        return sessions.get(uuid);
    }

    public void removeSession(UUID uuid) {
        PlayerSession session = sessions.remove(uuid);
        if (session != null) {
            session.cancelTimeoutTask();
        }
    }

    // -------------------------------------------------------------------------
    // State queries
    // -------------------------------------------------------------------------

    public boolean isAuthenticated(UUID uuid) {
        PlayerSession session = sessions.get(uuid);
        return session != null && session.isAuthenticated();
    }

    public boolean isAwaiting2FA(UUID uuid) {
        PlayerSession session = sessions.get(uuid);
        return session != null && session.isAwaiting2FA();
    }

    public void setAwaiting2FA(UUID uuid) {
        PlayerSession session = sessions.get(uuid);
        if (session != null) {
            session.setState(LoginState.AWAITING_2FA);
        }
    }

    // -------------------------------------------------------------------------
    // Authentication — MAIN THREAD ONLY
    // -------------------------------------------------------------------------

    /**
     * Marks the player as fully authenticated, cancels any pending timeout task,
     * removes the blindness effect, and makes the player mutually visible with all
     * other authenticated players.
     *
     * <p>Must be called on the main Bukkit thread.</p>
     */
    public void authenticate(Player player) {
        UUID uuid = player.getUniqueId();
        PlayerSession session = sessions.get(uuid);
        if (session == null) return;

        session.setState(LoginState.AUTHENTICATED);
        session.cancelTimeoutTask();

        // Remove auth restrictions
        player.removePotionEffect(PotionEffectType.BLINDNESS);

        // Make this player visible to / able to see all other authenticated players
        for (Player online : plugin.getServer().getOnlinePlayers()) {
            if (online.getUniqueId().equals(uuid)) continue;
            if (isAuthenticated(online.getUniqueId())) {
                player.showPlayer(plugin, online);
                online.showPlayer(plugin, player);
            }
        }
    }

    // -------------------------------------------------------------------------
    // Deauthentication — MAIN THREAD ONLY
    // -------------------------------------------------------------------------

    /**
     * Marks the player as unauthenticated.
     * If {@code persist} is true, saves a {@link PersistentSession} to the database
     * so the same IP can skip re-authentication on the next join within the
     * configured session-persistence window.
     *
     * <p>Must be called on the main Bukkit thread.</p>
     */
    public void deauthenticate(Player player, boolean persist) {
        UUID uuid = player.getUniqueId();
        PlayerSession session = sessions.get(uuid);
        if (session == null) return;

        if (persist) {
            long now    = System.currentTimeMillis();
            long expiry = now + ((long) plugin.getConfigManager().getSessionPersistence() * 1000);
            PersistentSession ps = new PersistentSession(uuid, session.getIp(), now, expiry);
            plugin.getDatabaseManager().getDatabase().saveSession(ps);
        }

        session.setState(LoginState.UNAUTHENTICATED);
        applyAuthRestrictions(player);
    }

    // -------------------------------------------------------------------------
    // Persistent session check
    // -------------------------------------------------------------------------

    /**
     * Asynchronously looks up a persistent session for the given player and IP.
     * If a valid session exists, the player is authenticated on the main thread.
     *
     * @return a future resolving to {@code true} if a session was resumed
     */
    public CompletableFuture<Boolean> checkPersistentSession(Player player, String ip) {
        UUID uuid = player.getUniqueId();
        return plugin.getDatabaseManager().getDatabase()
                .getSession(uuid)
                .thenApply(opt -> {
                    if (opt.isEmpty()) return false;
                    PersistentSession ps = opt.get();
                    if (!ps.isValid(ip)) {
                        // Stale session — remove it
                        plugin.getDatabaseManager().getDatabase().deleteSession(uuid);
                        return false;
                    }
                    return true;
                })
                .thenApply(valid -> {
                    if (valid) {
                        plugin.getServer().getScheduler().runTask(plugin, () -> {
                            if (player.isOnline()) {
                                authenticate(player);
                                player.sendMessage(plugin.getMessagesManager().get("session.resumed"));
                                plugin.getAuthLogger().logAuth(
                                        player.getName(), ip,
                                        com.yourname.bloodauth.model.AuthEvent.SESSION_RESUMED,
                                        "Persistent session resumed");
                                plugin.getDiscordWebhook().sendSessionResumed(
                                        player.getName(), uuid, ip, "");
                            }
                        });
                    }
                    return valid;
                });
    }

    // -------------------------------------------------------------------------
    // Auth restrictions — MAIN THREAD ONLY
    // -------------------------------------------------------------------------

    /**
     * Applies blindness and hides the player from (and hides) all authenticated
     * players. Called when a player joins or is deauthenticated.
     *
     * <p>Must be called on the main Bukkit thread.</p>
     */
    public void applyAuthRestrictions(Player player) {
        UUID uuid = player.getUniqueId();

        // Apply blindness
        player.addPotionEffect(new PotionEffect(
                PotionEffectType.BLINDNESS,
                Integer.MAX_VALUE,
                5,
                false,
                false,
                false));

        // Hide from / hide all authenticated players
        for (Player online : plugin.getServer().getOnlinePlayers()) {
            if (online.getUniqueId().equals(uuid)) continue;
            if (isAuthenticated(online.getUniqueId())) {
                online.hidePlayer(plugin, player);
                player.hidePlayer(plugin, online);
            }
        }
    }

    // -------------------------------------------------------------------------
    // Shutdown
    // -------------------------------------------------------------------------

    /**
     * Saves persistent sessions for all currently-authenticated online players,
     * then clears the session map.
     */
    public void shutdown() {
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            UUID uuid = player.getUniqueId();
            if (!isAuthenticated(uuid)) continue;
            PlayerSession session = sessions.get(uuid);
            if (session == null) continue;

            long now    = System.currentTimeMillis();
            long expiry = now + ((long) plugin.getConfigManager().getSessionPersistence() * 1000);
            PersistentSession ps = new PersistentSession(uuid, session.getIp(), now, expiry);
            plugin.getDatabaseManager().getDatabase().saveSession(ps);
        }
        sessions.clear();
    }
}
