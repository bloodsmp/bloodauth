package com.yourname.bloodauth;

import com.yourname.bloodauth.api.BloodAuthAPI;
import com.yourname.bloodauth.command.*;
import com.yourname.bloodauth.config.ConfigManager;
import com.yourname.bloodauth.config.MessagesManager;
import com.yourname.bloodauth.database.DatabaseManager;
import com.yourname.bloodauth.discord.DiscordWebhook;
import com.yourname.bloodauth.geoip.GeoIPManager;
import com.yourname.bloodauth.listener.AuthProtectionListener;
import com.yourname.bloodauth.listener.PlayerJoinListener;
import com.yourname.bloodauth.listener.PlayerQuitListener;
import com.yourname.bloodauth.logging.AuthLogger;
import com.yourname.bloodauth.security.PasswordManager;
import com.yourname.bloodauth.security.RateLimiter;
import com.yourname.bloodauth.security.SessionManager;
import com.yourname.bloodauth.security.TwoFactorManager;
import com.yourname.bloodauth.task.AccountPurgeTask;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Objects;
import java.util.logging.Level;

public final class BloodAuth extends JavaPlugin {

    private ConfigManager    configManager;
    private MessagesManager  messagesManager;
    private DatabaseManager  databaseManager;
    private SessionManager   sessionManager;
    private PasswordManager  passwordManager;
    private TwoFactorManager twoFactorManager;
    private RateLimiter      rateLimiter;
    private GeoIPManager     geoIPManager;
    private DiscordWebhook   discordWebhook;
    private AuthLogger       authLogger;
    private BloodAuthAPI     api;

    @Override
    public void onEnable() {
        long startMs = System.currentTimeMillis();

        saveDefaultConfig();
        configManager   = new ConfigManager(this);
        messagesManager = new MessagesManager(this);

        authLogger = new AuthLogger(this);
        try {
            authLogger.initialize();
        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Failed to initialise auth logger — disabling plugin.", e);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        databaseManager = new DatabaseManager(this);
        try {
            databaseManager.initialize();
        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Failed to connect to database — disabling plugin.", e);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        passwordManager  = new PasswordManager(this);
        twoFactorManager = new TwoFactorManager(this);
        rateLimiter      = new RateLimiter(this);
        sessionManager   = new SessionManager(this);
        geoIPManager     = new GeoIPManager(this);
        geoIPManager.initialize();
        discordWebhook   = new DiscordWebhook(this);

        var pm = getServer().getPluginManager();
        pm.registerEvents(new AuthProtectionListener(this), this);
        pm.registerEvents(new PlayerJoinListener(this),     this);
        pm.registerEvents(new PlayerQuitListener(this),     this);

        registerCommands();
        scheduleRecurringTasks();

        api = new BloodAuthAPI(this);

        getLogger().info("BloodAuth v" + getDescription().getVersion()
                + " enabled in " + (System.currentTimeMillis() - startMs) + " ms.");
    }

    @Override
    public void onDisable() {
        if (sessionManager   != null) sessionManager.shutdown();
        if (databaseManager  != null) databaseManager.shutdown();
        if (geoIPManager     != null) geoIPManager.shutdown();
        if (authLogger       != null) authLogger.shutdown();
        BloodAuthAPI.invalidate();
    }

    private void registerCommands() {
        requireCommand("register").setExecutor(new RegisterCommand(this));
        requireCommand("login").setExecutor(new LoginCommand(this));
        requireCommand("logout").setExecutor(new LogoutCommand(this));
        requireCommand("changepassword").setExecutor(new ChangePasswordCommand(this));
        requireCommand("2fa").setExecutor(new TwoFactorCommand(this));
        var ba  = new BloodAuthCommand(this);
        var cmd = requireCommand("bloodauth");
        cmd.setExecutor(ba);
        cmd.setTabCompleter(ba);
    }

    private void scheduleRecurringTasks() {
        int days = configManager.getPurgeInactiveDays();
        if (days > 0) {
            getServer().getScheduler().runTaskTimerAsynchronously(
                    this, new AccountPurgeTask(this), 20L * 60 * 5, 20L * 60 * 60 * 12);
        }
    }

    private org.bukkit.command.PluginCommand requireCommand(String name) {
        return Objects.requireNonNull(getCommand(name),
                "Command '" + name + "' missing from plugin.yml");
    }

    // Accessors
    public ConfigManager    getConfigManager()    { return configManager; }
    public MessagesManager  getMessagesManager()  { return messagesManager; }
    public DatabaseManager  getDatabaseManager()  { return databaseManager; }
    public SessionManager   getSessionManager()   { return sessionManager; }
    public PasswordManager  getPasswordManager()  { return passwordManager; }
    public TwoFactorManager getTwoFactorManager() { return twoFactorManager; }
    public RateLimiter      getRateLimiter()      { return rateLimiter; }
    public GeoIPManager     getGeoIPManager()     { return geoIPManager; }
    public DiscordWebhook   getDiscordWebhook()   { return discordWebhook; }
    public AuthLogger       getAuthLogger()       { return authLogger; }
    public BloodAuthAPI     getAPI()              { return api; }
}
