package com.yourname.bloodauth.config;

import com.yourname.bloodauth.BloodAuth;

import java.util.List;

public final class ConfigManager {

    private final BloodAuth plugin;

    public ConfigManager(BloodAuth plugin) {
        this.plugin = plugin;
    }

    /** Reloads config.yml from disk. */
    public void reload() {
        plugin.reloadConfig();
    }

    // -------------------------------------------------------------------------
    // Database
    // -------------------------------------------------------------------------

    public String getDatabaseType() {
        return plugin.getConfig().getString("database.type", "sqlite");
    }

    public String getMysqlHost() {
        return plugin.getConfig().getString("database.mysql.host", "localhost");
    }

    public int getMysqlPort() {
        return plugin.getConfig().getInt("database.mysql.port", 3306);
    }

    public String getMysqlDatabase() {
        return plugin.getConfig().getString("database.mysql.database", "bloodauth");
    }

    public String getMysqlUsername() {
        return plugin.getConfig().getString("database.mysql.username", "root");
    }

    public String getMysqlPassword() {
        return plugin.getConfig().getString("database.mysql.password", "");
    }

    public int getMysqlPoolSize() {
        return plugin.getConfig().getInt("database.mysql.pool-size", 5);
    }

    // -------------------------------------------------------------------------
    // Authentication
    // -------------------------------------------------------------------------

    public int getSessionTimeout() {
        return plugin.getConfig().getInt("authentication.session-timeout", 60);
    }

    public int getSessionPersistence() {
        return plugin.getConfig().getInt("authentication.session-persistence", 300);
    }

    public int getMaxLoginAttempts() {
        return plugin.getConfig().getInt("authentication.max-login-attempts", 5);
    }

    public int getTempBanDuration() {
        return plugin.getConfig().getInt("authentication.temp-ban-duration", 30);
    }

    public int getPasswordMinLength() {
        return plugin.getConfig().getInt("authentication.password-min-length", 6);
    }

    public int getPasswordMaxLength() {
        return plugin.getConfig().getInt("authentication.password-max-length", 32);
    }

    public long getRateLimitCooldown() {
        return plugin.getConfig().getLong("authentication.rate-limit-cooldown", 1000L);
    }

    // -------------------------------------------------------------------------
    // Security
    // -------------------------------------------------------------------------

    public int getBcryptCost() {
        int cost = plugin.getConfig().getInt("security.bcrypt-cost", 12);
        return Math.max(10, Math.min(31, cost));
    }

    public int getPurgeInactiveDays() {
        return plugin.getConfig().getInt("security.purge-inactive-days", 90);
    }

    public boolean isVpnCheckEnabled() {
        return plugin.getConfig().getBoolean("security.vpn-check.enabled", false);
    }

    public String getVpnApiUrl() {
        return plugin.getConfig().getString("security.vpn-check.api-url",
                "https://vpnapi.io/api/{ip}?key=YOUR_KEY");
    }

    public String getVpnJsonField() {
        return plugin.getConfig().getString("security.vpn-check.json-field", "security.vpn");
    }

    public boolean isVpnBlock() {
        return plugin.getConfig().getBoolean("security.vpn-check.block", true);
    }

    // -------------------------------------------------------------------------
    // GeoIP
    // -------------------------------------------------------------------------

    public boolean isGeoIPEnabled() {
        return plugin.getConfig().getBoolean("geoip.enabled", false);
    }

    public String getGeoIPDatabasePath() {
        return plugin.getConfig().getString("geoip.database-path",
                "plugins/BloodAuth/GeoLite2-Country.mmdb");
    }

    @SuppressWarnings("unchecked")
    public List<String> getBlockedCountries() {
        return (List<String>) plugin.getConfig().getList("geoip.blocked-countries", List.of());
    }

    @SuppressWarnings("unchecked")
    public List<String> getAllowedCountries() {
        return (List<String>) plugin.getConfig().getList("geoip.allowed-countries", List.of());
    }

    public boolean isNewCountryAlert() {
        return plugin.getConfig().getBoolean("geoip.new-country-alert", true);
    }

    public boolean isNewCountryKick() {
        return plugin.getConfig().getBoolean("geoip.new-country-kick", false);
    }

    public String getGeoIPBypassPermission() {
        return plugin.getConfig().getString("geoip.bypass-permission", "bloodauth.bypassgeo");
    }

    // -------------------------------------------------------------------------
    // Discord
    // -------------------------------------------------------------------------

    public boolean isDiscordEnabled() {
        return plugin.getConfig().getBoolean("discord.enabled", false);
    }

    public String getDiscordWebhookUrl() {
        return plugin.getConfig().getString("discord.webhook-url", "");
    }

    public String getDiscordServerName() {
        return plugin.getConfig().getString("discord.server-name", "My Server");
    }

    public boolean isDiscordEventEnabled(String key) {
        return plugin.getConfig().getBoolean("discord.events." + key, true);
    }
}
