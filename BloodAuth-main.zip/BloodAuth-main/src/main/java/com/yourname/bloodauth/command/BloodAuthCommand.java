package com.yourname.bloodauth.command;

import com.yourname.bloodauth.BloodAuth;
import com.yourname.bloodauth.model.AuthEvent;
import com.yourname.bloodauth.model.PlayerData;
import com.yourname.bloodauth.security.TOTPUtil;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;

public final class BloodAuthCommand implements CommandExecutor, TabCompleter {

    private static final List<String> SUB_COMMANDS =
            List.of("reload", "forcelogin", "forcelogout", "unregister",
                    "tempban", "info", "2fa");
    private static final List<String> SUB_2FA =
            List.of("enable", "disable", "reset");

    private final BloodAuth plugin;

    public BloodAuthCommand(BloodAuth plugin) {
        this.plugin = plugin;
    }

    // =========================================================================
    // Command dispatch
    // =========================================================================

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "reload"      -> handleReload(sender);
            case "forcelogin"  -> handleForceLogin(sender, args);
            case "forcelogout" -> handleForceLogout(sender, args);
            case "unregister"  -> handleUnregister(sender, args);
            case "tempban"     -> handleTempBan(sender, args);
            case "info"        -> handleInfo(sender, args);
            case "2fa"         -> handle2FA(sender, args);
            default            -> sendHelp(sender);
        }
        return true;
    }

    // =========================================================================
    // reload
    // =========================================================================

    private void handleReload(CommandSender sender) {
        if (!sender.hasPermission("bloodauth.admin")) {
            sender.sendMessage(plugin.getMessagesManager().get("general.no-permission"));
            return;
        }
        plugin.getConfigManager().reload();
        plugin.getMessagesManager().reload();
        sender.sendMessage(plugin.getMessagesManager().get("admin.reload-success"));
        plugin.getAuthLogger().logAuth(sender.getName(), "console",
                AuthEvent.ADMIN_FORCE_LOGIN, "Config reloaded by " + sender.getName());
    }

    // =========================================================================
    // forcelogin
    // =========================================================================

    private void handleForceLogin(CommandSender sender, String[] args) {
        if (!sender.hasPermission("bloodauth.admin")) {
            sender.sendMessage(plugin.getMessagesManager().get("general.no-permission"));
            return;
        }
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: /bloodauth forcelogin <player>");
            return;
        }
        String targetName = args[1];
        Player target = plugin.getServer().getPlayer(targetName);
        if (target == null) {
            sender.sendMessage(plugin.getMessagesManager().get("admin.player-not-online",
                    "player", targetName));
            return;
        }
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            plugin.getSessionManager().authenticate(target);
            sender.sendMessage(plugin.getMessagesManager().get("admin.forcelogin-success",
                    "player", target.getName()));
            plugin.getAuthLogger().logAuth(target.getName(), "admin",
                    AuthEvent.ADMIN_FORCE_LOGIN, "Force-logged in by " + sender.getName());
            plugin.getDiscordWebhook().sendAdminAction(sender.getName(),
                    "Force Login", target.getName());
        });
    }

    // =========================================================================
    // forcelogout
    // =========================================================================

    private void handleForceLogout(CommandSender sender, String[] args) {
        if (!sender.hasPermission("bloodauth.admin")) {
            sender.sendMessage(plugin.getMessagesManager().get("general.no-permission"));
            return;
        }
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: /bloodauth forcelogout <player>");
            return;
        }
        String targetName = args[1];
        Player target = plugin.getServer().getPlayer(targetName);
        if (target == null) {
            sender.sendMessage(plugin.getMessagesManager().get("admin.player-not-online",
                    "player", targetName));
            return;
        }
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            plugin.getSessionManager().deauthenticate(target, false);
            plugin.getDatabaseManager().getDatabase().deleteSession(target.getUniqueId());
            plugin.getSessionManager().applyAuthRestrictions(target);
            sender.sendMessage(plugin.getMessagesManager().get("admin.forcelogout-success",
                    "player", target.getName()));
            plugin.getAuthLogger().logAuth(target.getName(), "admin",
                    AuthEvent.ADMIN_FORCE_LOGOUT, "Force-logged out by " + sender.getName());
            plugin.getDiscordWebhook().sendAdminAction(sender.getName(),
                    "Force Logout", target.getName());
        });
    }

    // =========================================================================
    // unregister
    // =========================================================================

    private void handleUnregister(CommandSender sender, String[] args) {
        if (!sender.hasPermission("bloodauth.admin")) {
            sender.sendMessage(plugin.getMessagesManager().get("general.no-permission"));
            return;
        }
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: /bloodauth unregister <player>");
            return;
        }
        String targetName = args[1];

        plugin.getDatabaseManager().getDatabase()
                .getPlayerByName(targetName)
                .thenAccept(optData -> {
                    if (optData.isEmpty()) {
                        sender.sendMessage(plugin.getMessagesManager().get("admin.info-not-found",
                                "player", targetName));
                        return;
                    }
                    PlayerData data = optData.get();
                    UUID uuid = data.getUuid();

                    plugin.getDatabaseManager().getDatabase().deletePlayer(uuid);
                    plugin.getDatabaseManager().getDatabase().deleteSession(uuid);

                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        Player target = plugin.getServer().getPlayer(uuid);
                        if (target != null && target.isOnline()) {
                            target.kickPlayer(ChatColor.translateAlternateColorCodes('&',
                                    plugin.getMessagesManager().get("admin.unregister-success",
                                            "player", data.getUsername())));
                        }
                        sender.sendMessage(plugin.getMessagesManager().get(
                                "admin.unregister-success", "player", data.getUsername()));
                        plugin.getAuthLogger().logAuth(data.getUsername(), "admin",
                                AuthEvent.ADMIN_UNREGISTER,
                                "Unregistered by " + sender.getName());
                        plugin.getDiscordWebhook().sendAccountUnregistered(
                                data.getUsername(), uuid, sender.getName());
                    });
                })
                .exceptionally(ex -> {
                    plugin.getLogger().log(Level.SEVERE, "Error in unregister command.", ex);
                    return null;
                });
    }

    // =========================================================================
    // tempban
    // =========================================================================

    private void handleTempBan(CommandSender sender, String[] args) {
        if (!sender.hasPermission("bloodauth.admin")) {
            sender.sendMessage(plugin.getMessagesManager().get("general.no-permission"));
            return;
        }
        if (args.length < 3) {
            sender.sendMessage(plugin.getMessagesManager().get("admin.tempban-usage"));
            return;
        }
        String targetName = args[1];
        int minutes;
        try {
            minutes = Integer.parseInt(args[2]);
            if (minutes <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            sender.sendMessage(plugin.getMessagesManager().get("admin.tempban-usage"));
            return;
        }

        int finalMinutes = minutes;
        plugin.getDatabaseManager().getDatabase()
                .getPlayerByName(targetName)
                .thenAccept(optData -> {
                    if (optData.isEmpty()) {
                        sender.sendMessage(plugin.getMessagesManager().get("admin.info-not-found",
                                "player", targetName));
                        return;
                    }
                    PlayerData data = optData.get();
                    UUID uuid = data.getUuid();
                    long expiry = System.currentTimeMillis() + ((long) finalMinutes * 60_000);
                    data.setTempBanExpiry(expiry);

                    plugin.getDatabaseManager().getDatabase().savePlayer(data);

                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    String expiryStr = sdf.format(new Date(expiry));

                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        Player target = plugin.getServer().getPlayer(uuid);
                        if (target != null && target.isOnline()) {
                            target.kickPlayer(ChatColor.translateAlternateColorCodes('&',
                                    plugin.getMessagesManager().get("ban.temp-banned",
                                            "expiry", expiryStr)));
                        }
                        sender.sendMessage(plugin.getMessagesManager().get(
                                "admin.tempban-success",
                                "player", data.getUsername(),
                                "minutes", String.valueOf(finalMinutes)));
                        plugin.getAuthLogger().logAuth(data.getUsername(), "admin",
                                AuthEvent.ADMIN_TEMPBAN,
                                "Temp-banned " + finalMinutes + " min by " + sender.getName());
                        plugin.getDiscordWebhook().sendAdminAction(sender.getName(),
                                "Temp-ban " + finalMinutes + " min", data.getUsername());
                    });
                })
                .exceptionally(ex -> {
                    plugin.getLogger().log(Level.SEVERE, "Error in tempban command.", ex);
                    return null;
                });
    }

    // =========================================================================
    // info
    // =========================================================================

    private void handleInfo(CommandSender sender, String[] args) {
        if (!sender.hasPermission("bloodauth.admin")) {
            sender.sendMessage(plugin.getMessagesManager().get("general.no-permission"));
            return;
        }
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: /bloodauth info <player>");
            return;
        }
        String targetName = args[1];
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        plugin.getDatabaseManager().getDatabase()
                .getPlayerByName(targetName)
                .thenAccept(optData -> {
                    if (optData.isEmpty()) {
                        sender.sendMessage(plugin.getMessagesManager().get("admin.info-not-found",
                                "player", targetName));
                        return;
                    }
                    PlayerData data = optData.get();
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        sender.sendMessage(plugin.getMessagesManager().get("admin.info-header",
                                "player", data.getUsername()));
                        sendInfoLine(sender, "UUID",           data.getUuid().toString());
                        sendInfoLine(sender, "Registered",     sdf.format(new Date(data.getRegistrationTime())));
                        sendInfoLine(sender, "Last Login",     sdf.format(new Date(data.getLastLogin())));
                        sendInfoLine(sender, "Last IP",        data.getLastIp() != null ? data.getLastIp() : "N/A");
                        sendInfoLine(sender, "Reg. IP",        data.getRegistrationIp() != null ? data.getRegistrationIp() : "N/A");
                        sendInfoLine(sender, "Reg. Country",   data.getRegistrationCountry() != null ? data.getRegistrationCountry() : "N/A");
                        sendInfoLine(sender, "Last Country",   data.getLastCountry() != null ? data.getLastCountry() : "N/A");
                        sendInfoLine(sender, "2FA Enabled",    String.valueOf(data.isTotpEnabled()));
                        sendInfoLine(sender, "Failed Attempts",String.valueOf(data.getFailedAttempts()));
                        sendInfoLine(sender, "Temp-Banned",    data.isCurrentlyTempBanned()
                                ? "Yes (until " + sdf.format(new Date(data.getTempBanExpiry())) + ")"
                                : "No");
                    });
                })
                .exceptionally(ex -> {
                    plugin.getLogger().log(Level.SEVERE, "Error in info command.", ex);
                    return null;
                });
    }

    private void sendInfoLine(CommandSender sender, String key, String value) {
        sender.sendMessage(plugin.getMessagesManager().get("admin.info-line",
                "key", key, "value", value));
    }

    // =========================================================================
    // 2fa subcommand dispatcher
    // =========================================================================

    private void handle2FA(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: /bloodauth 2fa <enable|disable|reset> [args]");
            return;
        }

        String sub2 = args[1].toLowerCase();
        switch (sub2) {
            case "enable"  -> handle2FAEnable(sender);
            case "disable" -> {
                if (args.length < 3) {
                    sender.sendMessage(plugin.getMessagesManager().get("totp.disable-usage"));
                    return;
                }
                handle2FADisable(sender, args[2]);
            }
            case "reset"   -> {
                if (args.length < 3) {
                    sender.sendMessage(ChatColor.RED + "Usage: /bloodauth 2fa reset <player>");
                    return;
                }
                handle2FAReset(sender, args[2]);
            }
            default -> sender.sendMessage(ChatColor.RED
                    + "Usage: /bloodauth 2fa <enable|disable|reset>");
        }
    }

    // =========================================================================
    // 2fa enable
    // =========================================================================

    private void handle2FAEnable(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessagesManager().get("general.not-player"));
            return;
        }
        if (!plugin.getSessionManager().isAuthenticated(player.getUniqueId())) {
            player.sendMessage(plugin.getMessagesManager().get("general.not-authenticated"));
            return;
        }

        UUID uuid = player.getUniqueId();
        String ip = player.getAddress() != null
                ? player.getAddress().getAddress().getHostAddress() : "unknown";

        plugin.getDatabaseManager().getDatabase()
                .getPlayer(uuid)
                .thenAccept(optData -> {
                    if (optData.isEmpty()) return;
                    PlayerData data = optData.get();

                    if (data.isTotpEnabled()) {
                        plugin.getServer().getScheduler().runTask(plugin, () ->
                                player.sendMessage(plugin.getMessagesManager()
                                        .get("totp.already-enabled")));
                        return;
                    }

                    List<String> plainCodes = plugin.getTwoFactorManager().enable(data);

                    plugin.getDatabaseManager().getDatabase()
                            .savePlayer(data)
                            .thenRun(() -> {
                                if (!player.isOnline()) return;
                                plugin.getServer().getScheduler().runTask(plugin, () -> {
                                    // Send QR code as clickable link
                                    String qrUrl = TOTPUtil.buildQRCodeUrl(
                                            data.getTotpSecret(),
                                            player.getName(),
                                            plugin.getConfigManager().getDiscordServerName());

                                    player.sendMessage(plugin.getMessagesManager()
                                            .get("totp.qr-prompt"));

                                    TextComponent linkText = new TextComponent(
                                            ChatColor.translateAlternateColorCodes('&',
                                                    plugin.getMessagesManager().getRaw("totp.qr-clickable")));
                                    linkText.setClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, qrUrl));
                                    player.spigot().sendMessage(linkText);

                                    player.sendMessage(plugin.getMessagesManager()
                                            .get("totp.secret-display",
                                                    "secret", data.getTotpSecret()));

                                    player.sendMessage(plugin.getMessagesManager()
                                            .get("totp.backup-codes-header"));
                                    for (String code : plainCodes) {
                                        player.sendMessage(plugin.getMessagesManager()
                                                .get("totp.backup-code-entry", "code", code));
                                    }
                                    player.sendMessage(plugin.getMessagesManager()
                                            .get("totp.enabled"));

                                    plugin.getAuthLogger().logAuth(player.getName(), ip,
                                            AuthEvent.TOTP_ENABLED, "2FA enabled");
                                    plugin.getDiscordWebhook().sendTOTPEnabled(
                                            player.getName(), uuid);
                                });
                            })
                            .exceptionally(ex -> {
                                plugin.getLogger().log(Level.SEVERE,
                                        "Error saving 2FA enable for " + player.getName(), ex);
                                return null;
                            });
                })
                .exceptionally(ex -> {
                    plugin.getLogger().log(Level.SEVERE,
                            "Error in 2fa enable for " + player.getName(), ex);
                    return null;
                });
    }

    // =========================================================================
    // 2fa disable
    // =========================================================================

    private void handle2FADisable(CommandSender sender, String password) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessagesManager().get("general.not-player"));
            return;
        }
        if (!plugin.getSessionManager().isAuthenticated(player.getUniqueId())) {
            player.sendMessage(plugin.getMessagesManager().get("general.not-authenticated"));
            return;
        }

        UUID uuid = player.getUniqueId();
        String ip = player.getAddress() != null
                ? player.getAddress().getAddress().getHostAddress() : "unknown";

        plugin.getDatabaseManager().getDatabase()
                .getPlayer(uuid)
                .thenAccept(optData -> {
                    if (optData.isEmpty()) return;
                    PlayerData data = optData.get();

                    if (!data.isTotpEnabled()) {
                        plugin.getServer().getScheduler().runTask(plugin, () ->
                                player.sendMessage(plugin.getMessagesManager()
                                        .get("totp.not-enabled")));
                        return;
                    }

                    if (!plugin.getPasswordManager().verify(password, data.getPasswordHash())) {
                        plugin.getServer().getScheduler().runTask(plugin, () ->
                                player.sendMessage(plugin.getMessagesManager()
                                        .get("login.wrong-password",
                                                "attempts", "?",
                                                "max", "?")));
                        return;
                    }

                    plugin.getTwoFactorManager().disable(data);

                    plugin.getDatabaseManager().getDatabase()
                            .savePlayer(data)
                            .thenRun(() -> {
                                if (!player.isOnline()) return;
                                plugin.getServer().getScheduler().runTask(plugin, () -> {
                                    player.sendMessage(plugin.getMessagesManager()
                                            .get("totp.disabled"));
                                    plugin.getAuthLogger().logAuth(player.getName(), ip,
                                            AuthEvent.TOTP_DISABLED, "2FA disabled");
                                    plugin.getDiscordWebhook().sendTOTPDisabled(
                                            player.getName(), uuid);
                                });
                            })
                            .exceptionally(ex -> {
                                plugin.getLogger().log(Level.SEVERE,
                                        "Error saving 2FA disable for " + player.getName(), ex);
                                return null;
                            });
                })
                .exceptionally(ex -> {
                    plugin.getLogger().log(Level.SEVERE,
                            "Error in 2fa disable for " + player.getName(), ex);
                    return null;
                });
    }

    // =========================================================================
    // 2fa reset (admin)
    // =========================================================================

    private void handle2FAReset(CommandSender sender, String targetName) {
        if (!sender.hasPermission("bloodauth.admin")) {
            sender.sendMessage(plugin.getMessagesManager().get("general.no-permission"));
            return;
        }

        plugin.getDatabaseManager().getDatabase()
                .getPlayerByName(targetName)
                .thenAccept(optData -> {
                    if (optData.isEmpty()) {
                        sender.sendMessage(plugin.getMessagesManager().get("admin.info-not-found",
                                "player", targetName));
                        return;
                    }
                    PlayerData data = optData.get();
                    plugin.getTwoFactorManager().disable(data);

                    plugin.getDatabaseManager().getDatabase()
                            .savePlayer(data)
                            .thenRun(() -> plugin.getServer().getScheduler().runTask(plugin, () -> {
                                sender.sendMessage(plugin.getMessagesManager().get(
                                        "totp.reset-success", "player", data.getUsername()));
                                plugin.getAuthLogger().logAuth(data.getUsername(), "admin",
                                        AuthEvent.ADMIN_2FA_RESET,
                                        "2FA reset by " + sender.getName());
                                plugin.getDiscordWebhook().sendAdminAction(sender.getName(),
                                        "2FA Reset", data.getUsername());
                            }))
                            .exceptionally(ex -> {
                                plugin.getLogger().log(Level.SEVERE,
                                        "Error saving 2FA reset for " + targetName, ex);
                                return null;
                            });
                })
                .exceptionally(ex -> {
                    plugin.getLogger().log(Level.SEVERE,
                            "Error in 2fa reset for " + targetName, ex);
                    return null;
                });
    }

    // =========================================================================
    // Help
    // =========================================================================

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                plugin.getMessagesManager().getRaw("admin.help-header")));

        String[][] help = {
                {"bloodauth reload",           "Reload configuration"},
                {"bloodauth forcelogin <p>",   "Force-authenticate a player"},
                {"bloodauth forcelogout <p>",  "Force-deauthenticate a player"},
                {"bloodauth unregister <p>",   "Delete a player's account"},
                {"bloodauth tempban <p> <m>",  "Temp-ban a player for <m> minutes"},
                {"bloodauth info <p>",         "Show account details"},
                {"bloodauth 2fa enable",       "Enable 2FA on your account"},
                {"bloodauth 2fa disable <pw>", "Disable 2FA (requires password)"},
                {"bloodauth 2fa reset <p>",    "Admin: reset 2FA for a player"},
        };

        for (String[] entry : help) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                    plugin.getMessagesManager().getRaw("admin.help-line",
                            "cmd", entry[0], "desc", entry[1])));
        }
    }

    // =========================================================================
    // Tab completion
    // =========================================================================

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command,
                                      String alias, String[] args) {
        if (!sender.hasPermission("bloodauth.admin")) return List.of();

        if (args.length == 1) {
            return SUB_COMMANDS.stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .toList();
        }

        if (args.length == 2 && args[0].equalsIgnoreCase("2fa")) {
            return SUB_2FA.stream()
                    .filter(s -> s.startsWith(args[1].toLowerCase()))
                    .toList();
        }

        // For subcommands that take a player name as second arg
        if (args.length == 2) {
            String sub = args[0].toLowerCase();
            if (Arrays.asList("forcelogin", "forcelogout", "unregister",
                    "tempban", "info").contains(sub)) {
                return plugin.getServer().getOnlinePlayers().stream()
                        .map(Player::getName)
                        .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase()))
                        .toList();
            }
        }

        // /bloodauth 2fa reset <player>
        if (args.length == 3 && args[0].equalsIgnoreCase("2fa")
                && args[1].equalsIgnoreCase("reset")) {
            return plugin.getServer().getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[2].toLowerCase()))
                    .toList();
        }

        return List.of();
    }
}
