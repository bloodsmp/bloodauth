package com.yourname.bloodauth.security;

import org.apache.commons.codec.binary.Base32;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

public final class TOTPUtil {

    private static final int    TIME_STEP     = 30;       // seconds per TOTP window
    private static final int    DIGITS        = 6;        // OTP digits
    private static final long   MODULUS       = 1_000_000L; // 10^6
    private static final String HMAC_ALGO     = "HmacSHA1";
    private static final String BACKUP_CHARS  = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private static final int    BACKUP_LENGTH = 8;
    private static final SecureRandom RANDOM  = new SecureRandom();

    private TOTPUtil() {}

    // -------------------------------------------------------------------------
    // Secret generation
    // -------------------------------------------------------------------------

    /**
     * Generates a 20-byte random secret encoded as Base32 (no padding).
     */
    public static String generateSecret() {
        byte[] bytes = new byte[20];
        RANDOM.nextBytes(bytes);
        return new Base32().encodeToString(bytes).replace("=", "");
    }

    // -------------------------------------------------------------------------
    // TOTP verification
    // -------------------------------------------------------------------------

    /**
     * Verifies a 6-digit TOTP code against the given Base32 secret,
     * allowing a ±1 time-step window to account for clock skew.
     */
    public static boolean verifyCode(String secret, String code) {
        if (secret == null || code == null || code.length() != DIGITS) return false;
        long counter = System.currentTimeMillis() / 1000 / TIME_STEP;

        byte[] key;
        try {
            key = new Base32().decode(secret.toUpperCase());
        } catch (Exception e) {
            return false;
        }

        for (int delta = -1; delta <= 1; delta++) {
            int hotp = computeHOTP(key, counter + delta);
            String expected = String.format("%0" + DIGITS + "d", hotp);
            if (expected.equals(code)) return true;
        }
        return false;
    }

    /**
     * Computes a single HOTP value using HmacSHA1.
     * counter is encoded big-endian in 8 bytes; dynamic truncation extracts 6 digits.
     */
    public static int computeHOTP(byte[] key, long counter) {
        byte[] counterBytes = ByteBuffer.allocate(8).putLong(counter).array();
        try {
            Mac mac = Mac.getInstance(HMAC_ALGO);
            mac.init(new SecretKeySpec(key, HMAC_ALGO));
            byte[] digest = mac.doFinal(counterBytes);

            // Dynamic truncation
            int offset = digest[digest.length - 1] & 0x0F;
            int binary = ((digest[offset]     & 0x7F) << 24)
                       | ((digest[offset + 1] & 0xFF) << 16)
                       | ((digest[offset + 2] & 0xFF) <<  8)
                       |  (digest[offset + 3] & 0xFF);

            return (int) (binary % MODULUS);
        } catch (NoSuchAlgorithmException | InvalidKeyException e) {
            throw new RuntimeException("TOTP computation failed", e);
        }
    }

    // -------------------------------------------------------------------------
    // QR code URL
    // -------------------------------------------------------------------------

    /**
     * Builds a QR code image URL using api.qrserver.com for the given TOTP secret,
     * account name, and issuer. All components are URL-encoded.
     */
    public static String buildQRCodeUrl(String secret, String accountName, String issuer) {
        String otpAuthData = "otpauth://totp/"
                + urlEncode(issuer) + ":" + urlEncode(accountName)
                + "?secret=" + urlEncode(secret)
                + "&issuer=" + urlEncode(issuer);

        return "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data="
                + urlEncode(otpAuthData);
    }

    private static String urlEncode(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8).replace("+", "%20");
    }

    // -------------------------------------------------------------------------
    // Backup codes
    // -------------------------------------------------------------------------

    /**
     * Generates {@code count} random backup codes, each {@value #BACKUP_LENGTH}
     * characters long drawn from the alphanumeric charset.
     */
    public static List<String> generateBackupCodes(int count) {
        List<String> codes = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            StringBuilder sb = new StringBuilder(BACKUP_LENGTH);
            for (int j = 0; j < BACKUP_LENGTH; j++) {
                sb.append(BACKUP_CHARS.charAt(RANDOM.nextInt(BACKUP_CHARS.length())));
            }
            codes.add(sb.toString());
        }
        return codes;
    }
}
