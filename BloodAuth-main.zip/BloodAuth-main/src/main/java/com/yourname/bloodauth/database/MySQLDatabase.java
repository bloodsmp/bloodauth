package com.yourname.bloodauth.database;

import com.yourname.bloodauth.BloodAuth;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.sql.Connection;
import java.sql.SQLException;

public final class MySQLDatabase extends AbstractDatabase {

    private final BloodAuth plugin;
    private HikariDataSource dataSource;

    public MySQLDatabase(BloodAuth plugin) {
        this.plugin = plugin;
    }

    @Override
    public void connect() throws Exception {
        var cfg = plugin.getConfigManager();

        HikariConfig config = new HikariConfig();
        config.setPoolName("BloodAuth-MySQL");
        config.setJdbcUrl("jdbc:mysql://"
                + cfg.getMysqlHost() + ":"
                + cfg.getMysqlPort() + "/"
                + cfg.getMysqlDatabase()
                + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC");
        config.setUsername(cfg.getMysqlUsername());
        config.setPassword(cfg.getMysqlPassword());
        config.setMaximumPoolSize(cfg.getMysqlPoolSize());

        // Performance optimisations recommended by HikariCP for MySQL
        config.addDataSourceProperty("cachePrepStmts",          "true");
        config.addDataSourceProperty("prepStmtCacheSize",        "250");
        config.addDataSourceProperty("prepStmtCacheSqlLimit",   "2048");
        config.addDataSourceProperty("useServerPrepStmts",       "true");
        config.addDataSourceProperty("useLocalSessionState",     "true");
        config.addDataSourceProperty("rewriteBatchedStatements", "true");
        config.addDataSourceProperty("cacheResultSetMetadata",   "true");
        config.addDataSourceProperty("cacheServerConfiguration", "true");
        config.addDataSourceProperty("elideSetAutoCommits",      "true");
        config.addDataSourceProperty("maintainTimeStats",        "false");

        dataSource = new HikariDataSource(config);
        createTables();
    }

    @Override
    public void disconnect() {
        executor.shutdown();
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
        }
    }

    @Override
    protected Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    @Override
    protected String upsertKeyword() {
        return "REPLACE";
    }
}
