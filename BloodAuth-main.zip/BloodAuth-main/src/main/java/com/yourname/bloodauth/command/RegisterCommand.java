package com.yourname.bloodauth.command;

import com.yourname.bloodauth.BloodAuth;
import com.yourname.bloodauth.model.AuthEvent;
import com.yourname.bloodauth.model.PlayerData;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.logging.Level;

public final class RegisterCommand implements CommandExecutor {

    private final BloodAuth plugin;

    public RegisterCommand(BloodAuth plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // Guard: player only
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessagesManager().get("general.not-player"));
            return true;
        }

        var uuid = player.getUniqueId();

        // Guard: already authenticated
        if (plugin.getSessionManager().isAuthenticated(uuid)) {
            player.sendMessage(plugin.getMessagesManager().get("register.already-authenticated"));
            return true;
        }

        // Guard: rate limit
        if (!plugin.getRateLimiter().tryConsume(uuid)) {
            player.sendMessage(plugin.getMessagesManager().get("general.rate-limited",
                    "seconds", String.valueOf(plugin.getRateLimiter().remainingSeconds(uuid))));
            return true;
        }

        // Guard: argument count
        if (args.length != 2) {
            player.sendMessage(plugin.getMessagesManager().get("register.usage"));
            return true;
        }

        String password = args[0];
        String confirm  = args[1];

        // Guard: password mismatch
        if (!password.equals(confirm)) {
            player.sendMessage(plugin.getMessagesManager().get("register.password-mismatch"));
            return true;
        }

        int min = plugin.getConfigManager().getPasswordMinLength();
        int max = plugin.getConfigManager().getPasswordMaxLength();

        // Guard: password too short
        if (password.length() < min) {
            player.sendMessage(plugin.getMessagesManager().get("register.password-too-short",
                    "min", String.valueOf(min)));
            return true;
        }

        // Guard: password too long
        if (password.length() > max) {
            player.sendMessage(plugin.getMessagesManager().get("register.password-too-long",
                    "max", String.valueOf(max)));
            return true;
        }

        String ip = player.getAddress() != null
                ? player.getAddress().getAddress().getHostAddress()
                : "unknown";

        // Async flow: check if registered → hash → save → authenticate
        plugin.getDatabaseManager().getDatabase()
                .isRegistered(uuid)
                .thenAccept(registered -> {
                    if (!player.isOnline()) return;

                    if (registered) {
                        plugin.getServer().getScheduler().runTask(plugin, () ->
                                player.sendMessage(plugin.getMessagesManager()
                                        .get("register.already-registered")));
                        return;
                    }

                    String hash = plugin.getPasswordManager().hash(password);
                    PlayerData data = new PlayerData(uuid, player.getName(), hash, ip, null);

                    plugin.getDatabaseManager().getDatabase()
                            .savePlayer(data)
                            .thenRun(() -> {
                                if (!player.isOnline()) return;
                                plugin.getServer().getScheduler().runTask(plugin, () -> {
                                    plugin.getSessionManager().authenticate(player);
                                    player.sendMessage(plugin.getMessagesManager()
                                            .get("register.success"));
                                    plugin.getAuthLogger().logAuth(
                                            player.getName(), ip, AuthEvent.REGISTER,
                                            "New account registered");
                                    plugin.getDiscordWebhook().sendNewRegistration(
                                            player.getName(), uuid, ip, null);
                                });
                            })
                            .exceptionally(ex -> {
                                plugin.getLogger().log(Level.SEVERE,
                                        "Error saving new player " + player.getName(), ex);
                                return null;
                            });
                })
                .exceptionally(ex -> {
                    plugin.getLogger().log(Level.SEVERE,
                            "Error checking registration for " + player.getName(), ex);
                    return null;
                });

        return true;
    }
}
