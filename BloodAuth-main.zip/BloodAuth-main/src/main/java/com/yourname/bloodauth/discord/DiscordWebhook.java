package com.yourname.bloodauth.discord;

import com.yourname.bloodauth.BloodAuth;
import com.yourname.bloodauth.util.CountryUtil;
import com.yourname.bloodauth.util.IPUtil;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.util.UUID;
import java.util.logging.Level;

public final class DiscordWebhook {

    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();

    private final BloodAuth plugin;

    public DiscordWebhook(BloodAuth plugin) {
        this.plugin = plugin;
    }

    // -------------------------------------------------------------------------
    // Gate check
    // -------------------------------------------------------------------------

    private boolean shouldSend(String eventKey) {
        return plugin.getConfigManager().isDiscordEnabled()
                && plugin.getConfigManager().isDiscordEventEnabled(eventKey);
    }

    // -------------------------------------------------------------------------
    // Public send methods
    // -------------------------------------------------------------------------

    public void sendLoginSuccess(String name, UUID uuid, String ip, String country) {
        if (!shouldSend("login-success")) return;
        post(0x2ECC71, "Login Success", name, uuid, ip, country);
    }

    public void sendLoginFailed(String name, UUID uuid, String ip, int attempts, int max) {
        if (!shouldSend("login-failed")) return;
        post(0xE67E22, "Login Failed", name, uuid, ip, null,
                "Attempts", attempts + "/" + max);
    }

    public void sendAccountLocked(String name, UUID uuid, String ip) {
        if (!shouldSend("account-locked")) return;
        post(0xE74C3C, "Account Locked", name, uuid, ip, null);
    }

    public void sendNewRegistration(String name, UUID uuid, String ip, String country) {
        if (!shouldSend("new-registration")) return;
        post(0x3498DB, "New Registration", name, uuid, ip, country);
    }

    public void sendPasswordChanged(String name, UUID uuid, String ip) {
        if (!shouldSend("password-changed")) return;
        post(0x9B59B6, "Password Changed", name, uuid, ip, null);
    }

    public void sendSessionResumed(String name, UUID uuid, String ip, String country) {
        if (!shouldSend("session-resumed")) return;
        post(0x1ABC9C, "Session Resumed", name, uuid, ip, country);
    }

    public void sendTOTPEnabled(String name, UUID uuid) {
        if (!shouldSend("totp-enabled")) return;
        post(0x27AE60, "2FA Enabled", name, uuid, null, null);
    }

    public void sendTOTPDisabled(String name, UUID uuid) {
        if (!shouldSend("totp-disabled")) return;
        post(0xF1C40F, "2FA Disabled", name, uuid, null, null);
    }

    public void sendNewCountryLogin(String name, UUID uuid, String ip,
                                    String oldCountry, String newCountry) {
        if (!shouldSend("new-country-login")) return;
        post(0xE67E22, "New Country Login", name, uuid, ip, newCountry,
                "Previous Country", CountryUtil.getFlagWithCode(oldCountry));
    }

    public void sendGeoIPBlocked(String name, UUID uuid, String ip, String country) {
        if (!shouldSend("geoip-blocked")) return;
        post(0xE74C3C, "GeoIP Blocked", name, uuid, ip, country);
    }

    public void sendVPNDetected(String name, UUID uuid, String ip) {
        if (!shouldSend("vpn-detected")) return;
        post(0xC0392B, "VPN Detected", name, uuid, ip, null);
    }

    public void sendAccountUnregistered(String name, UUID uuid, String adminName) {
        if (!shouldSend("account-unregistered")) return;
        post(0x922B21, "Account Deleted", name, uuid, null, null,
                "Deleted By", adminName);
    }

    public void sendAdminAction(String adminName, String action, String targetName) {
        if (!shouldSend("admin-action")) return;
        post(0x95A5A6, "Admin Action", adminName, null, null, null,
                "Action", action,
                "Target", targetName);
    }

    // -------------------------------------------------------------------------
    // Core post logic
    // -------------------------------------------------------------------------

    private void post(int color, String title, String playerName, UUID uuid,
                      String ip, String country, String... extras) {
        String webhookUrl = plugin.getConfigManager().getDiscordWebhookUrl();
        if (webhookUrl == null || webhookUrl.isBlank() || webhookUrl.contains("YOUR_WEBHOOK")) return;

        String json = buildJson(color, title, playerName, uuid, ip, country, extras);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(webhookUrl))
                .timeout(Duration.ofSeconds(10))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

        HTTP.sendAsync(request, HttpResponse.BodyHandlers.discarding())
                .exceptionally(ex -> {
                    plugin.getLogger().log(Level.WARNING,
                            "Failed to send Discord webhook: " + ex.getMessage());
                    return null;
                });
    }

    // -------------------------------------------------------------------------
    // JSON builder
    // -------------------------------------------------------------------------

    String buildJson(int color, String title, String playerName, UUID uuid,
                     String ip, String country, String... extras) {
        String serverName = plugin.getConfigManager().getDiscordServerName();
        StringBuilder fields = new StringBuilder();

        appendField(fields, "Player", playerName != null ? playerName : "N/A", true);

        if (uuid != null) {
            appendField(fields, "UUID", uuid.toString(), false);
        }

        if (ip != null) {
            appendField(fields, "IP", IPUtil.maskIP(ip), true);
        }

        if (country != null && !country.isBlank()) {
            appendField(fields, "Country", CountryUtil.getFlagWithCode(country), true);
        }

        // Extra key-value pairs
        if (extras != null) {
            for (int i = 0; i + 1 < extras.length; i += 2) {
                String k = extras[i];
                String v = extras[i + 1];
                if (k != null && v != null) {
                    appendField(fields, k, v, true);
                }
            }
        }

        // Trim trailing comma from fields list
        String fieldsStr = fields.toString();
        if (fieldsStr.endsWith(",")) {
            fieldsStr = fieldsStr.substring(0, fieldsStr.length() - 1);
        }

        return "{"
                + "\"username\":\"" + esc(serverName) + " | BloodAuth\","
                + "\"embeds\":[{"
                + "\"title\":\"" + esc(title) + "\","
                + "\"color\":" + color + ","
                + "\"fields\":[" + fieldsStr + "],"
                + "\"footer\":{\"text\":\"" + esc(serverName) + " \u2022 BloodAuth\"},"
                + "\"timestamp\":\"" + Instant.now().toString() + "\""
                + "}]}";
    }

    private void appendField(StringBuilder sb, String name, String value, boolean inline) {
        sb.append("{")
          .append("\"name\":\"").append(esc(name)).append("\",")
          .append("\"value\":\"").append(esc(value)).append("\",")
          .append("\"inline\":").append(inline)
          .append("},");
    }

    /** Escapes characters that would break a JSON string literal. */
    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}
