package com.yourname.bloodauth.logging;

import com.yourname.bloodauth.BloodAuth;
import com.yourname.bloodauth.model.AuthEvent;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

public final class AuthLogger {

    private static final DateTimeFormatter FORMATTER =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final BloodAuth plugin;
    private ExecutorService executor;
    private BufferedWriter  authWriter;
    private BufferedWriter  geoipWriter;

    public AuthLogger(BloodAuth plugin) {
        this.plugin = plugin;
    }

    /**
     * Creates the log directory and opens both log files in append mode.
     * Must be called once during plugin enable before any log methods are used.
     */
    public void initialize() throws IOException {
        File logsDir = new File(plugin.getDataFolder(), "logs");
        if (!logsDir.exists() && !logsDir.mkdirs()) {
            throw new IOException("Could not create logs directory: " + logsDir.getAbsolutePath());
        }

        Path authPath  = logsDir.toPath().resolve("auth.log");
        Path geoipPath = logsDir.toPath().resolve("geoip.log");

        authWriter  = Files.newBufferedWriter(authPath,
                StandardOpenOption.APPEND, StandardOpenOption.CREATE);
        geoipWriter = Files.newBufferedWriter(geoipPath,
                StandardOpenOption.APPEND, StandardOpenOption.CREATE);

        executor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "BloodAuth-Logger");
            t.setDaemon(true);
            return t;
        });
    }

    /**
     * Asynchronously writes an auth event line to auth.log.
     * Format: [yyyy-MM-dd HH:mm:ss] [AUTH] playerName | ip | EVENT | details
     */
    public void logAuth(String playerName, String ip, AuthEvent event, String details) {
        if (executor == null || executor.isShutdown()) return;
        String timestamp = LocalDateTime.now().format(FORMATTER);
        String line = "[" + timestamp + "] [AUTH] " + playerName + " | " + ip
                + " | " + event.name() + " | " + details;
        executor.submit(() -> writeLine(authWriter, line));
    }

    /**
     * Asynchronously writes a GeoIP event line to geoip.log.
     * Format: [yyyy-MM-dd HH:mm:ss] [GEOIP] playerName | ip | countryCode | outcome
     */
    public void logGeoIP(String playerName, String ip, String countryCode, String outcome) {
        if (executor == null || executor.isShutdown()) return;
        String timestamp = LocalDateTime.now().format(FORMATTER);
        String line = "[" + timestamp + "] [GEOIP] " + playerName + " | " + ip
                + " | " + countryCode + " | " + outcome;
        executor.submit(() -> writeLine(geoipWriter, line));
    }

    private void writeLine(BufferedWriter writer, String line) {
        try {
            writer.write(line);
            writer.newLine();
            writer.flush();
        } catch (IOException e) {
            plugin.getLogger().log(Level.WARNING, "Failed to write to log file.", e);
        }
    }

    /**
     * Flushes and closes both log files, then shuts down the executor.
     * Waits up to 5 seconds for pending log tasks to complete.
     */
    public void shutdown() {
        if (executor == null) return;
        executor.submit(() -> {
            closeWriter(authWriter);
            closeWriter(geoipWriter);
        });
        executor.shutdown();
        try {
            if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            executor.shutdownNow();
        }
    }

    private void closeWriter(BufferedWriter writer) {
        if (writer == null) return;
        try {
            writer.flush();
            writer.close();
        } catch (IOException e) {
            plugin.getLogger().log(Level.WARNING, "Failed to close log writer.", e);
        }
    }
}
