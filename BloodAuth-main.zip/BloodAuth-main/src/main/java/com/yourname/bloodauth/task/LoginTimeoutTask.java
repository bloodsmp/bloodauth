package com.yourname.bloodauth.task;

import com.yourname.bloodauth.BloodAuth;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.UUID;

public final class LoginTimeoutTask extends BukkitRunnable {

    private final BloodAuth plugin;
    private final UUID uuid;

    public LoginTimeoutTask(BloodAuth plugin, UUID uuid) {
        this.plugin = plugin;
        this.uuid   = uuid;
    }

    @Override
    public void run() {
        Player player = plugin.getServer().getPlayer(uuid);
        if (player == null || !player.isOnline()) return;
        if (plugin.getSessionManager().isAuthenticated(uuid)) return;

        player.kickPlayer(plugin.getMessagesManager().get("timeout.kicked"));
    }
}
