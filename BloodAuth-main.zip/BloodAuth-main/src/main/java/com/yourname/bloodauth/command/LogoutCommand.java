package com.yourname.bloodauth.command;

import com.yourname.bloodauth.BloodAuth;
import com.yourname.bloodauth.model.AuthEvent;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class LogoutCommand implements CommandExecutor {

    private final BloodAuth plugin;

    public LogoutCommand(BloodAuth plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessagesManager().get("general.not-player"));
            return true;
        }

        var uuid = player.getUniqueId();

        if (!plugin.getSessionManager().isAuthenticated(uuid)) {
            player.sendMessage(plugin.getMessagesManager().get("logout.not-authenticated"));
            return true;
        }

        // Deauthenticate without persisting session (forcing re-login on next join)
        plugin.getSessionManager().deauthenticate(player, false);
        plugin.getDatabaseManager().getDatabase().deleteSession(uuid);
        plugin.getSessionManager().applyAuthRestrictions(player);

        player.sendMessage(plugin.getMessagesManager().get("logout.success"));
        plugin.getAuthLogger().logAuth(player.getName(), player.getAddress() != null
                ? player.getAddress().getAddress().getHostAddress() : "unknown",
                AuthEvent.LOGOUT, "Manual logout");

        return true;
    }
}
