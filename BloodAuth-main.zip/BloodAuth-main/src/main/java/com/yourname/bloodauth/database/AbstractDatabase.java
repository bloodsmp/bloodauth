package com.yourname.bloodauth.database;

import com.yourname.bloodauth.model.PersistentSession;
import com.yourname.bloodauth.model.PlayerData;

import java.sql.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public abstract class AbstractDatabase implements Database {

    protected ExecutorService executor = Executors.newFixedThreadPool(3, r -> {
        Thread t = new Thread(r, "BloodAuth-DB");
        t.setDaemon(true);
        return t;
    });

    // -------------------------------------------------------------------------
    // Abstract helpers
    // -------------------------------------------------------------------------

    /** Returns a connection from the underlying pool. */
    protected abstract Connection getConnection() throws SQLException;

    /**
     * Returns the SQL keyword used for upsert operations.
     * SQLite uses "INSERT OR REPLACE"; MySQL uses "REPLACE".
     */
    protected abstract String upsertKeyword();

    // -------------------------------------------------------------------------
    // Table creation
    // -------------------------------------------------------------------------

    protected void createTables() throws SQLException {
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(
                    "CREATE TABLE IF NOT EXISTS ba_players ("
                    + "uuid                TEXT    NOT NULL PRIMARY KEY,"
                    + "username            TEXT    NOT NULL,"
                    + "password_hash       TEXT    NOT NULL,"
                    + "email               TEXT,"
                    + "registration_time   BIGINT  NOT NULL DEFAULT 0,"
                    + "last_login          BIGINT  NOT NULL DEFAULT 0,"
                    + "last_ip             TEXT,"
                    + "registration_ip     TEXT,"
                    + "registration_country TEXT,"
                    + "last_country        TEXT,"
                    + "totp_enabled        INT     NOT NULL DEFAULT 0,"
                    + "totp_secret         TEXT,"
                    + "backup_codes        TEXT,"
                    + "failed_attempts     INT     NOT NULL DEFAULT 0,"
                    + "temp_ban_expiry     BIGINT  NOT NULL DEFAULT 0"
                    + ")"
            );

            stmt.executeUpdate(
                    "CREATE TABLE IF NOT EXISTS ba_sessions ("
                    + "uuid        TEXT    NOT NULL PRIMARY KEY,"
                    + "ip          TEXT    NOT NULL,"
                    + "login_time  BIGINT  NOT NULL DEFAULT 0,"
                    + "expiry      BIGINT  NOT NULL DEFAULT 0"
                    + ")"
            );
        }
    }

    // -------------------------------------------------------------------------
    // Row mappers
    // -------------------------------------------------------------------------

    private PlayerData mapPlayer(ResultSet rs) throws SQLException {
        return new PlayerData(
                UUID.fromString(rs.getString("uuid")),
                rs.getString("username"),
                rs.getString("password_hash"),
                rs.getString("email"),
                rs.getLong("registration_time"),
                rs.getLong("last_login"),
                rs.getString("last_ip"),
                rs.getString("registration_ip"),
                rs.getString("registration_country"),
                rs.getString("last_country"),
                rs.getInt("totp_enabled") == 1,
                rs.getString("totp_secret"),
                rs.getString("backup_codes"),
                rs.getInt("failed_attempts"),
                rs.getLong("temp_ban_expiry")
        );
    }

    private PersistentSession mapSession(ResultSet rs) throws SQLException {
        return new PersistentSession(
                UUID.fromString(rs.getString("uuid")),
                rs.getString("ip"),
                rs.getLong("login_time"),
                rs.getLong("expiry")
        );
    }

    // -------------------------------------------------------------------------
    // Interface implementations
    // -------------------------------------------------------------------------

    @Override
    public CompletableFuture<Optional<PlayerData>> getPlayer(UUID uuid) {
        return CompletableFuture.supplyAsync(() -> {
            try (Connection conn = getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "SELECT * FROM ba_players WHERE uuid = ?")) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return Optional.of(mapPlayer(rs));
                }
            } catch (SQLException e) {
                throw new RuntimeException("getPlayer failed", e);
            }
            return Optional.empty();
        }, executor);
    }

    @Override
    public CompletableFuture<Optional<PlayerData>> getPlayerByName(String username) {
        return CompletableFuture.supplyAsync(() -> {
            try (Connection conn = getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "SELECT * FROM ba_players WHERE LOWER(username) = LOWER(?)")) {
                ps.setString(1, username);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return Optional.of(mapPlayer(rs));
                }
            } catch (SQLException e) {
                throw new RuntimeException("getPlayerByName failed", e);
            }
            return Optional.empty();
        }, executor);
    }

    @Override
    public CompletableFuture<Void> savePlayer(PlayerData data) {
        return CompletableFuture.runAsync(() -> {
            String sql = upsertKeyword() + " INTO ba_players "
                    + "(uuid, username, password_hash, email, registration_time, last_login, "
                    + "last_ip, registration_ip, registration_country, last_country, "
                    + "totp_enabled, totp_secret, backup_codes, failed_attempts, temp_ban_expiry) "
                    + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            try (Connection conn = getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1,  data.getUuid().toString());
                ps.setString(2,  data.getUsername());
                ps.setString(3,  data.getPasswordHash());
                ps.setString(4,  data.getEmail());
                ps.setLong(5,    data.getRegistrationTime());
                ps.setLong(6,    data.getLastLogin());
                ps.setString(7,  data.getLastIp());
                ps.setString(8,  data.getRegistrationIp());
                ps.setString(9,  data.getRegistrationCountry());
                ps.setString(10, data.getLastCountry());
                ps.setInt(11,    data.isTotpEnabled() ? 1 : 0);
                ps.setString(12, data.getTotpSecret());
                ps.setString(13, data.getBackupCodesRaw());
                ps.setInt(14,    data.getFailedAttempts());
                ps.setLong(15,   data.getTempBanExpiry());
                ps.executeUpdate();
            } catch (SQLException e) {
                throw new RuntimeException("savePlayer failed", e);
            }
        }, executor);
    }

    @Override
    public CompletableFuture<Void> deletePlayer(UUID uuid) {
        return CompletableFuture.runAsync(() -> {
            try (Connection conn = getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "DELETE FROM ba_players WHERE uuid = ?")) {
                ps.setString(1, uuid.toString());
                ps.executeUpdate();
            } catch (SQLException e) {
                throw new RuntimeException("deletePlayer failed", e);
            }
        }, executor);
    }

    @Override
    public CompletableFuture<Optional<PersistentSession>> getSession(UUID uuid) {
        return CompletableFuture.supplyAsync(() -> {
            try (Connection conn = getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "SELECT * FROM ba_sessions WHERE uuid = ?")) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return Optional.of(mapSession(rs));
                }
            } catch (SQLException e) {
                throw new RuntimeException("getSession failed", e);
            }
            return Optional.empty();
        }, executor);
    }

    @Override
    public CompletableFuture<Void> saveSession(PersistentSession session) {
        return CompletableFuture.runAsync(() -> {
            String sql = upsertKeyword() + " INTO ba_sessions (uuid, ip, login_time, expiry) "
                    + "VALUES (?,?,?,?)";
            try (Connection conn = getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, session.uuid().toString());
                ps.setString(2, session.ip());
                ps.setLong(3,   session.loginTime());
                ps.setLong(4,   session.expiry());
                ps.executeUpdate();
            } catch (SQLException e) {
                throw new RuntimeException("saveSession failed", e);
            }
        }, executor);
    }

    @Override
    public CompletableFuture<Void> deleteSession(UUID uuid) {
        return CompletableFuture.runAsync(() -> {
            try (Connection conn = getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "DELETE FROM ba_sessions WHERE uuid = ?")) {
                ps.setString(1, uuid.toString());
                ps.executeUpdate();
            } catch (SQLException e) {
                throw new RuntimeException("deleteSession failed", e);
            }
        }, executor);
    }

    @Override
    public CompletableFuture<Boolean> isRegistered(UUID uuid) {
        return CompletableFuture.supplyAsync(() -> {
            try (Connection conn = getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "SELECT 1 FROM ba_players WHERE uuid = ? LIMIT 1")) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next();
                }
            } catch (SQLException e) {
                throw new RuntimeException("isRegistered failed", e);
            }
        }, executor);
    }

    @Override
    public CompletableFuture<List<UUID>> getInactivePlayers(long cutoffTimestamp) {
        return CompletableFuture.supplyAsync(() -> {
            List<UUID> result = new ArrayList<>();
            try (Connection conn = getConnection();
                 PreparedStatement ps = conn.prepareStatement(
                         "SELECT uuid FROM ba_players WHERE last_login < ?")) {
                ps.setLong(1, cutoffTimestamp);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        result.add(UUID.fromString(rs.getString("uuid")));
                    }
                }
            } catch (SQLException e) {
                throw new RuntimeException("getInactivePlayers failed", e);
            }
            return result;
        }, executor);
    }
}
