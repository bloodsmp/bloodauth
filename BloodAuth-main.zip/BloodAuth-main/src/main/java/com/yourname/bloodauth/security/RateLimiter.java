package com.yourname.bloodauth.security;

import com.yourname.bloodauth.BloodAuth;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class RateLimiter {

    private final BloodAuth plugin;
    private final ConcurrentHashMap<UUID, Long> lastUsed = new ConcurrentHashMap<>();

    public RateLimiter(BloodAuth plugin) {
        this.plugin = plugin;
    }

    /**
     * Returns true if the player may use an auth command (i.e. cooldown has elapsed).
     * Updates the last-used timestamp if allowed.
     */
    public boolean tryConsume(UUID uuid) {
        long cooldown = plugin.getConfigManager().getRateLimitCooldown();
        long now      = System.currentTimeMillis();
        Long last     = lastUsed.get(uuid);
        if (last != null && (now - last) < cooldown) {
            return false;
        }
        lastUsed.put(uuid, now);
        return true;
    }

    /** Returns the remaining cooldown in whole seconds (rounded up). */
    public long remainingSeconds(UUID uuid) {
        long cooldown = plugin.getConfigManager().getRateLimitCooldown();
        Long last     = lastUsed.get(uuid);
        if (last == null) return 0;
        long remaining = cooldown - (System.currentTimeMillis() - last);
        return remaining <= 0 ? 0 : (long) Math.ceil(remaining / 1000.0);
    }

    /** Removes the player's rate-limit entry (called on quit). */
    public void remove(UUID uuid) {
        lastUsed.remove(uuid);
    }
}
