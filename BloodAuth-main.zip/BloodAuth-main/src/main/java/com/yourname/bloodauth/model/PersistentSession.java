package com.yourname.bloodauth.model;

import java.util.UUID;

public record PersistentSession(UUID uuid, String ip, long loginTime, long expiry) {

    /**
     * Returns true if the session has not expired AND the incoming IP matches
     * the IP stored in the session.
     */
    public boolean isValid(String incomingIp) {
        return System.currentTimeMillis() < expiry && ip.equals(incomingIp);
    }
}
