package com.yourname.bloodauth.config;

import com.yourname.bloodauth.BloodAuth;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;

public final class MessagesManager {

    private final BloodAuth plugin;
    private FileConfiguration messages;
    private File messagesFile;

    public MessagesManager(BloodAuth plugin) {
        this.plugin = plugin;
        this.messagesFile = new File(plugin.getDataFolder(), "messages.yml");
        if (!messagesFile.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        reload();
    }

    /**
     * Reloads messages.yml from disk, merging any missing keys from the bundled
     * default resource so the file stays forward-compatible.
     */
    public void reload() {
        messages = YamlConfiguration.loadConfiguration(messagesFile);

        InputStream defaultStream = plugin.getResource("messages.yml");
        if (defaultStream != null) {
            YamlConfiguration defaults = YamlConfiguration.loadConfiguration(
                    new InputStreamReader(defaultStream, StandardCharsets.UTF_8));
            messages.setDefaults(defaults);
            messages.options().copyDefaults(true);

            // Persist any newly-added default keys back to disk
            try {
                messages.save(messagesFile);
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Could not save updated messages.yml.", e);
            }
        }
    }

    /**
     * Retrieves a message by dot-separated key, applies the prefix, substitutes
     * placeholder pairs (key, value, key2, value2, …), and translates colour codes.
     *
     * @param key          dot-separated messages.yml key
     * @param placeholders alternating placeholder-name / replacement pairs
     * @return fully coloured and formatted message string
     */
    public String get(String key, String... placeholders) {
        String raw = getRaw(key);
        return ChatColor.translateAlternateColorCodes('&', raw);
    }

    /**
     * Same as {@link #get(String, String...)} but skips the final ChatColor
     * translation step — useful when embedding text inside JSON payloads.
     */
    public String getRaw(String key, String... placeholders) {
        String prefix = messages.getString("prefix", "&c[&4BloodAuth&c]&r");
        String raw    = messages.getString(key, "&c[BloodAuth] Missing message: " + key);

        // Substitute {prefix}
        raw = raw.replace("{prefix}", prefix);

        // Substitute caller-supplied placeholders (pairs: name, value)
        if (placeholders != null) {
            for (int i = 0; i + 1 < placeholders.length; i += 2) {
                String placeholder = placeholders[i];
                String value       = placeholders[i + 1];
                if (placeholder != null && value != null) {
                    raw = raw.replace("{" + placeholder + "}", value);
                }
            }
        }

        return raw;
    }
}
