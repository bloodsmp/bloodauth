package com.yourname.bloodauth.listener;

import com.yourname.bloodauth.BloodAuth;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;

import java.util.Set;

public final class AuthProtectionListener implements Listener {

    private static final Set<String> PRE_AUTH_COMMANDS   = Set.of("login", "register", "l", "reg");
    private static final Set<String> AWAITING_2FA_CMDS   = Set.of("2fa");

    private final BloodAuth plugin;

    public AuthProtectionListener(BloodAuth plugin) {
        this.plugin = plugin;
    }

    // -------------------------------------------------------------------------
    // Movement — allow head rotation, block position changes
    // -------------------------------------------------------------------------

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onMove(PlayerMoveEvent event) {
        if (isNotAuthenticated(event.getPlayer())) {
            var from = event.getFrom();
            var to   = event.getTo();
            if (to == null) return;
            // Only block XYZ movement; allow yaw/pitch (head rotation)
            if (from.getX() != to.getX()
                    || from.getY() != to.getY()
                    || from.getZ() != to.getZ()) {
                event.setTo(from.clone());
            }
        }
    }

    // -------------------------------------------------------------------------
    // Chat
    // -------------------------------------------------------------------------

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onChat(AsyncPlayerChatEvent event) {
        if (isNotAuthenticated(event.getPlayer())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(plugin.getMessagesManager().get("general.please-login"));
        }
    }

    // -------------------------------------------------------------------------
    // Commands
    // -------------------------------------------------------------------------

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        String message = event.getMessage();

        // Extract the base label (strip '/' and take the first word)
        String label = message.substring(1).split("\\s+")[0].toLowerCase();
        // Strip any plugin prefix (e.g. "bloodauth:login" -> "login")
        if (label.contains(":")) {
            label = label.substring(label.indexOf(':') + 1);
        }

        if (plugin.getSessionManager().isAuthenticated(player.getUniqueId())) {
            return; // No restriction for authenticated players
        }

        if (plugin.getSessionManager().isAwaiting2FA(player.getUniqueId())) {
            if (!AWAITING_2FA_CMDS.contains(label)) {
                event.setCancelled(true);
                player.sendMessage(plugin.getMessagesManager().get("totp.usage"));
            }
            return;
        }

        // UNAUTHENTICATED
        if (!PRE_AUTH_COMMANDS.contains(label)) {
            event.setCancelled(true);
            player.sendMessage(plugin.getMessagesManager().get("general.please-login"));
        }
    }

    // -------------------------------------------------------------------------
    // Block interaction
    // -------------------------------------------------------------------------

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBlockBreak(BlockBreakEvent event) {
        if (isNotAuthenticated(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBlockPlace(BlockPlaceEvent event) {
        if (isNotAuthenticated(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInteract(PlayerInteractEvent event) {
        if (isNotAuthenticated(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInteractEntity(PlayerInteractEntityEvent event) {
        if (isNotAuthenticated(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    // -------------------------------------------------------------------------
    // Inventory / items
    // -------------------------------------------------------------------------

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player player && isNotAuthenticated(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDropItem(PlayerDropItemEvent event) {
        if (isNotAuthenticated(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPickupItem(EntityPickupItemEvent event) {
        if (event.getEntity() instanceof Player player && isNotAuthenticated(player)) {
            event.setCancelled(true);
        }
    }

    // -------------------------------------------------------------------------
    // Damage
    // -------------------------------------------------------------------------

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDamage(EntityDamageEvent event) {
        Entity entity = event.getEntity();
        if (entity instanceof Player player && isNotAuthenticated(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDamageByEntity(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player player && isNotAuthenticated(player)) {
            event.setCancelled(true);
        }
    }

    // -------------------------------------------------------------------------
    // Food
    // -------------------------------------------------------------------------

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onFoodLevel(FoodLevelChangeEvent event) {
        if (event.getEntity() instanceof Player player && isNotAuthenticated(player)) {
            event.setCancelled(true);
        }
    }

    // -------------------------------------------------------------------------
    // Helper
    // -------------------------------------------------------------------------

    private boolean isNotAuthenticated(Player player) {
        return !plugin.getSessionManager().isAuthenticated(player.getUniqueId());
    }
}
