package com.yourname.bloodauth.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public final class PlayerData {

    private UUID   uuid;
    private String username;
    private String passwordHash;
    private String email;
    private long   registrationTime;
    private long   lastLogin;
    private String lastIp;
    private String registrationIp;
    private String registrationCountry;
    private String lastCountry;
    private boolean totpEnabled;
    private String  totpSecret;
    private String  backupCodesRaw;
    private int     failedAttempts;
    private long    tempBanExpiry;

    /** Full constructor with all 15 fields. */
    public PlayerData(UUID uuid,
                      String username,
                      String passwordHash,
                      String email,
                      long registrationTime,
                      long lastLogin,
                      String lastIp,
                      String registrationIp,
                      String registrationCountry,
                      String lastCountry,
                      boolean totpEnabled,
                      String totpSecret,
                      String backupCodesRaw,
                      int failedAttempts,
                      long tempBanExpiry) {
        this.uuid                = uuid;
        this.username            = username;
        this.passwordHash        = passwordHash;
        this.email               = email;
        this.registrationTime    = registrationTime;
        this.lastLogin           = lastLogin;
        this.lastIp              = lastIp;
        this.registrationIp      = registrationIp;
        this.registrationCountry = registrationCountry;
        this.lastCountry         = lastCountry;
        this.totpEnabled         = totpEnabled;
        this.totpSecret          = totpSecret;
        this.backupCodesRaw      = backupCodesRaw;
        this.failedAttempts      = failedAttempts;
        this.tempBanExpiry       = tempBanExpiry;
    }

    /**
     * Convenience constructor for new registrations.
     * Sets registration/last login times to now; defaults everything else.
     */
    public PlayerData(UUID uuid, String username, String passwordHash, String ip, String country) {
        long now                 = System.currentTimeMillis();
        this.uuid                = uuid;
        this.username            = username;
        this.passwordHash        = passwordHash;
        this.email               = null;
        this.registrationTime    = now;
        this.lastLogin           = now;
        this.lastIp              = ip;
        this.registrationIp      = ip;
        this.registrationCountry = country;
        this.lastCountry         = country;
        this.totpEnabled         = false;
        this.totpSecret          = null;
        this.backupCodesRaw      = null;
        this.failedAttempts      = 0;
        this.tempBanExpiry       = 0L;
    }

    // -------------------------------------------------------------------------
    // Business methods
    // -------------------------------------------------------------------------

    public boolean isCurrentlyTempBanned() {
        return tempBanExpiry > 0 && System.currentTimeMillis() < tempBanExpiry;
    }

    public long getRemainingBanMinutes() {
        return Math.max(0, (tempBanExpiry - System.currentTimeMillis()) / 60000);
    }

    /**
     * Returns the list of BCrypt-hashed backup codes split by "|".
     * Empty strings (consumed codes) are included so indices remain stable until
     * the caller re-serialises the list.
     */
    public List<String> getBackupCodeHashes() {
        if (backupCodesRaw == null || backupCodesRaw.isBlank()) {
            return new ArrayList<>();
        }
        return new ArrayList<>(Arrays.asList(backupCodesRaw.split("\\|", -1)));
    }

    /** Joins the list back with "|" and stores it. */
    public void setBackupCodeHashes(List<String> hashes) {
        this.backupCodesRaw = String.join("|", hashes);
    }

    // -------------------------------------------------------------------------
    // Getters
    // -------------------------------------------------------------------------

    public UUID    getUuid()                { return uuid; }
    public String  getUsername()            { return username; }
    public String  getPasswordHash()        { return passwordHash; }
    public String  getEmail()               { return email; }
    public long    getRegistrationTime()    { return registrationTime; }
    public long    getLastLogin()           { return lastLogin; }
    public String  getLastIp()              { return lastIp; }
    public String  getRegistrationIp()      { return registrationIp; }
    public String  getRegistrationCountry() { return registrationCountry; }
    public String  getLastCountry()         { return lastCountry; }
    public boolean isTotpEnabled()          { return totpEnabled; }
    public String  getTotpSecret()          { return totpSecret; }
    public String  getBackupCodesRaw()      { return backupCodesRaw; }
    public int     getFailedAttempts()      { return failedAttempts; }
    public long    getTempBanExpiry()       { return tempBanExpiry; }

    // -------------------------------------------------------------------------
    // Setters
    // -------------------------------------------------------------------------

    public void setUuid(UUID uuid)                            { this.uuid = uuid; }
    public void setUsername(String username)                  { this.username = username; }
    public void setPasswordHash(String passwordHash)          { this.passwordHash = passwordHash; }
    public void setEmail(String email)                        { this.email = email; }
    public void setRegistrationTime(long registrationTime)    { this.registrationTime = registrationTime; }
    public void setLastLogin(long lastLogin)                  { this.lastLogin = lastLogin; }
    public void setLastIp(String lastIp)                      { this.lastIp = lastIp; }
    public void setRegistrationIp(String registrationIp)      { this.registrationIp = registrationIp; }
    public void setRegistrationCountry(String country)        { this.registrationCountry = country; }
    public void setLastCountry(String lastCountry)            { this.lastCountry = lastCountry; }
    public void setTotpEnabled(boolean totpEnabled)           { this.totpEnabled = totpEnabled; }
    public void setTotpSecret(String totpSecret)              { this.totpSecret = totpSecret; }
    public void setBackupCodesRaw(String backupCodesRaw)      { this.backupCodesRaw = backupCodesRaw; }
    public void setFailedAttempts(int failedAttempts)         { this.failedAttempts = failedAttempts; }
    public void setTempBanExpiry(long tempBanExpiry)          { this.tempBanExpiry = tempBanExpiry; }
}
