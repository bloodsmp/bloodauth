package com.yourname.bloodauth.command;

import com.yourname.bloodauth.BloodAuth;
import com.yourname.bloodauth.model.AuthEvent;
import com.yourname.bloodauth.model.PlayerData;
import com.yourname.bloodauth.security.TwoFactorManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;
import java.util.logging.Level;

public final class TwoFactorCommand implements CommandExecutor {

    private final BloodAuth plugin;

    public TwoFactorCommand(BloodAuth plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // Guard: player only
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessagesManager().get("general.not-player"));
            return true;
        }

        UUID uuid = player.getUniqueId();

        // Guard: must be awaiting 2FA
        if (!plugin.getSessionManager().isAwaiting2FA(uuid)) {
            player.sendMessage(plugin.getMessagesManager().get("totp.not-awaiting"));
            return true;
        }

        // Guard: rate limit
        if (!plugin.getRateLimiter().tryConsume(uuid)) {
            player.sendMessage(plugin.getMessagesManager().get("general.rate-limited",
                    "seconds", String.valueOf(plugin.getRateLimiter().remainingSeconds(uuid))));
            return true;
        }

        // Guard: argument count
        if (args.length != 1) {
            player.sendMessage(plugin.getMessagesManager().get("totp.usage"));
            return true;
        }

        String code = args[0];
        String ip = player.getAddress() != null
                ? player.getAddress().getAddress().getHostAddress()
                : "unknown";

        // Async: load player data and verify
        plugin.getDatabaseManager().getDatabase()
                .getPlayer(uuid)
                .thenAccept(optData -> {
                    if (!player.isOnline()) return;

                    if (optData.isEmpty()) {
                        return; // Should not happen — player passed login already
                    }

                    PlayerData data = optData.get();
                    TwoFactorManager.VerifyResult result =
                            plugin.getTwoFactorManager().verify(data, code);

                    switch (result) {
                        case VALID_TOTP -> {
                            finalizeLogin(player, data, ip);
                            plugin.getServer().getScheduler().runTask(plugin, () -> {
                                if (player.isOnline()) {
                                    player.sendMessage(plugin.getMessagesManager().get("totp.success"));
                                }
                            });
                            plugin.getAuthLogger().logAuth(player.getName(), ip,
                                    AuthEvent.TOTP_VERIFIED, "TOTP code verified");
                        }

                        case VALID_BACKUP -> {
                            // Save data first (backup code consumed)
                            plugin.getDatabaseManager().getDatabase()
                                    .savePlayer(data)
                                    .thenRun(() -> finalizeLogin(player, data, ip));

                            int remaining = plugin.getTwoFactorManager()
                                    .countRemainingBackupCodes(data);
                            plugin.getServer().getScheduler().runTask(plugin, () -> {
                                if (player.isOnline()) {
                                    player.sendMessage(plugin.getMessagesManager().get(
                                            "totp.backup-used",
                                            "remaining", String.valueOf(remaining)));
                                }
                            });
                            plugin.getAuthLogger().logAuth(player.getName(), ip,
                                    AuthEvent.BACKUP_CODE_USED,
                                    "Backup code used. Remaining: " + remaining);
                        }

                        case INVALID -> {
                            plugin.getServer().getScheduler().runTask(plugin, () -> {
                                if (player.isOnline()) {
                                    player.sendMessage(plugin.getMessagesManager()
                                            .get("totp.wrong-code"));
                                }
                            });
                            plugin.getAuthLogger().logAuth(player.getName(), ip,
                                    AuthEvent.TOTP_FAILED, "Invalid 2FA code entered");
                        }
                    }
                })
                .exceptionally(ex -> {
                    plugin.getLogger().log(Level.SEVERE,
                            "Error during 2FA verification for " + player.getName(), ex);
                    return null;
                });

        return true;
    }

    /**
     * Updates last-login metadata, saves, and authenticates the player on the main thread.
     */
    private void finalizeLogin(Player player, PlayerData data, String ip) {
        UUID uuid = player.getUniqueId();
        data.setLastLogin(System.currentTimeMillis());
        data.setLastIp(ip);

        plugin.getDatabaseManager().getDatabase()
                .savePlayer(data)
                .thenRun(() -> {
                    if (!player.isOnline()) return;
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        plugin.getSessionManager().authenticate(player);
                        player.sendMessage(plugin.getMessagesManager().get("login.success"));
                        plugin.getAuthLogger().logAuth(player.getName(), ip,
                                AuthEvent.LOGIN_SUCCESS, "2FA login");
                        plugin.getDiscordWebhook().sendLoginSuccess(
                                player.getName(), uuid, ip,
                                data.getLastCountry() != null ? data.getLastCountry() : "");
                    });
                })
                .exceptionally(ex -> {
                    plugin.getLogger().log(Level.SEVERE,
                            "Error finalizing 2FA login for " + player.getName(), ex);
                    return null;
                });
    }
}
