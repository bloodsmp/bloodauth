package com.yourname.bloodauth.security;

import com.yourname.bloodauth.BloodAuth;
import com.yourname.bloodauth.model.PlayerData;
import org.mindrot.jbcrypt.BCrypt;

import java.util.ArrayList;
import java.util.List;

public final class TwoFactorManager {

    public enum VerifyResult {
        VALID_TOTP,
        VALID_BACKUP,
        INVALID
    }

    private static final int BACKUP_CODE_COUNT  = 5;
    private static final int BACKUP_BCRYPT_COST = 10;

    private final BloodAuth plugin;

    public TwoFactorManager(BloodAuth plugin) {
        this.plugin = plugin;
    }

    // -------------------------------------------------------------------------
    // Enable
    // -------------------------------------------------------------------------

    /**
     * Generates a TOTP secret and 5 backup codes for the player, hashes the backup
     * codes, stores everything in {@code data}, and returns the plaintext backup codes.
     *
     * @param data player whose account should have 2FA enabled
     * @return list of plaintext backup codes (show to the player once, then discard)
     */
    public List<String> enable(PlayerData data) {
        String secret = TOTPUtil.generateSecret();
        List<String> plainCodes = TOTPUtil.generateBackupCodes(BACKUP_CODE_COUNT);

        List<String> hashedCodes = new ArrayList<>(BACKUP_CODE_COUNT);
        for (String code : plainCodes) {
            hashedCodes.add(BCrypt.hashpw(code, BCrypt.gensalt(BACKUP_BCRYPT_COST)));
        }

        data.setTotpSecret(secret);
        data.setTotpEnabled(true);
        data.setBackupCodeHashes(hashedCodes);

        return plainCodes;
    }

    // -------------------------------------------------------------------------
    // Disable
    // -------------------------------------------------------------------------

    /**
     * Clears all 2FA data from the player account.
     */
    public void disable(PlayerData data) {
        data.setTotpEnabled(false);
        data.setTotpSecret(null);
        data.setBackupCodesRaw(null);
    }

    // -------------------------------------------------------------------------
    // Verify
    // -------------------------------------------------------------------------

    /**
     * Verifies the supplied input against the player's TOTP code or backup codes.
     *
     * <ul>
     *   <li>If {@code input} is exactly 6 numeric digits: TOTP verification.</li>
     *   <li>Otherwise: backup code verification; the matched slot is consumed (cleared).</li>
     * </ul>
     *
     * @param data  player data containing the TOTP secret and backup code hashes
     * @param input the code entered by the player
     * @return the appropriate {@link VerifyResult}
     */
    public VerifyResult verify(PlayerData data, String input) {
        if (input == null || input.isBlank()) return VerifyResult.INVALID;

        if (input.matches("\\d{6}")) {
            // TOTP path
            boolean valid = TOTPUtil.verifyCode(data.getTotpSecret(), input);
            return valid ? VerifyResult.VALID_TOTP : VerifyResult.INVALID;
        }

        // Backup code path
        List<String> hashes = data.getBackupCodeHashes();
        for (int i = 0; i < hashes.size(); i++) {
            String hash = hashes.get(i);
            if (hash == null || hash.isBlank()) continue; // already consumed
            try {
                if (BCrypt.checkpw(input, hash)) {
                    // Consume this slot
                    hashes.set(i, "");
                    data.setBackupCodeHashes(hashes);
                    return VerifyResult.VALID_BACKUP;
                }
            } catch (IllegalArgumentException ignored) {
                // Malformed hash — skip
            }
        }

        return VerifyResult.INVALID;
    }

    /**
     * Counts the remaining (non-consumed) backup codes stored in the player's data.
     */
    public int countRemainingBackupCodes(PlayerData data) {
        return (int) data.getBackupCodeHashes().stream()
                .filter(h -> h != null && !h.isBlank())
                .count();
    }
}
