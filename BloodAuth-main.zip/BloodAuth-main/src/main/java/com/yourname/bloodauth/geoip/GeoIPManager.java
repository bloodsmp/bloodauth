package com.yourname.bloodauth.geoip;

import com.maxmind.geoip2.DatabaseReader;
import com.maxmind.geoip2.exception.AddressNotFoundException;
import com.yourname.bloodauth.BloodAuth;

import java.io.File;
import java.net.InetAddress;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

public final class GeoIPManager {

    private final BloodAuth plugin;
    private DatabaseReader  reader;
    private ExecutorService executor;
    private boolean         available = false;

    public GeoIPManager(BloodAuth plugin) {
        this.plugin = plugin;
    }

    // -------------------------------------------------------------------------
    // Initialization
    // -------------------------------------------------------------------------

    public void initialize() {
        if (!plugin.getConfigManager().isGeoIPEnabled()) {
            return;
        }

        executor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "BloodAuth-GeoIP");
            t.setDaemon(true);
            return t;
        });

        String path = plugin.getConfigManager().getGeoIPDatabasePath();
        File dbFile = new File(path);

        if (!dbFile.exists()) {
            plugin.getLogger().warning("╔══════════════════════════════════════════════════╗");
            plugin.getLogger().warning("║           BloodAuth — GeoIP Warning              ║");
            plugin.getLogger().warning("╠══════════════════════════════════════════════════╣");
            plugin.getLogger().warning("║ GeoLite2-Country.mmdb was NOT found at:          ║");
            plugin.getLogger().warning("║   " + path);
            plugin.getLogger().warning("║                                                  ║");
            plugin.getLogger().warning("║ Download it from MaxMind (free account required):║");
            plugin.getLogger().warning("║   https://dev.maxmind.com/geoip/geolite2-free-  ║");
            plugin.getLogger().warning("║   geolocation-data                               ║");
            plugin.getLogger().warning("║                                                  ║");
            plugin.getLogger().warning("║ Place the .mmdb file at the path above and       ║");
            plugin.getLogger().warning("║ run /bloodauth reload to activate GeoIP.         ║");
            plugin.getLogger().warning("╚══════════════════════════════════════════════════╝");
            available = false;
            return;
        }

        try {
            reader    = new DatabaseReader.Builder(dbFile).build();
            available = true;
            plugin.getLogger().info("GeoIP database loaded from: " + dbFile.getAbsolutePath());
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Failed to open GeoIP database.", e);
            available = false;
        }
    }

    // -------------------------------------------------------------------------
    // State
    // -------------------------------------------------------------------------

    public boolean isAvailable() {
        return available && plugin.getConfigManager().isGeoIPEnabled();
    }

    // -------------------------------------------------------------------------
    // Country lookup
    // -------------------------------------------------------------------------

    /**
     * Asynchronously resolves the ISO 3166-1 alpha-2 country code for the given IP.
     * Returns {@code "LOCAL"} for loopback/site-local addresses and {@code null}
     * when the IP is not found in the database.
     */
    public CompletableFuture<String> lookupCountry(String ip) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                InetAddress addr = InetAddress.getByName(ip);
                if (addr.isLoopbackAddress() || addr.isSiteLocalAddress()) {
                    return "LOCAL";
                }
                return reader.country(addr).getCountry().getIsoCode();
            } catch (AddressNotFoundException e) {
                return null;
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "GeoIP lookup failed for " + ip, e);
                return null;
            }
        }, executor);
    }

    // -------------------------------------------------------------------------
    // Country filtering
    // -------------------------------------------------------------------------

    /**
     * Returns {@code true} if the country code should be denied access based on the
     * configured allowed/blocked country lists.
     *
     * <ul>
     *   <li>If {@code allowedCountries} is non-empty and the code is <em>not</em> in it → blocked.</li>
     *   <li>If the code is in {@code blockedCountries} → blocked.</li>
     * </ul>
     */
    public boolean isCountryBlocked(String code) {
        if (code == null) return false;
        String upper = code.toUpperCase();

        List<String> allowed = plugin.getConfigManager().getAllowedCountries();
        if (allowed != null && !allowed.isEmpty()) {
            return allowed.stream().noneMatch(c -> c.equalsIgnoreCase(upper));
        }

        List<String> blocked = plugin.getConfigManager().getBlockedCountries();
        if (blocked != null) {
            return blocked.stream().anyMatch(c -> c.equalsIgnoreCase(upper));
        }

        return false;
    }

    // -------------------------------------------------------------------------
    // Shutdown
    // -------------------------------------------------------------------------

    public void shutdown() {
        if (executor != null) {
            executor.shutdown();
            try {
                if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                    executor.shutdownNow();
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                executor.shutdownNow();
            }
        }
        if (reader != null) {
            try {
                reader.close();
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Error closing GeoIP reader.", e);
            }
        }
    }
}
