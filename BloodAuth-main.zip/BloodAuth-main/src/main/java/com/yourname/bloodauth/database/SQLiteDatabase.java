package com.yourname.bloodauth.database;

import com.yourname.bloodauth.BloodAuth;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;

public final class SQLiteDatabase extends AbstractDatabase {

    private final BloodAuth plugin;
    private HikariDataSource dataSource;

    public SQLiteDatabase(BloodAuth plugin) {
        this.plugin = plugin;
    }

    @Override
    public void connect() throws Exception {
        File dbFile = new File(plugin.getDataFolder(), "bloodauth.db");
        dbFile.getParentFile().mkdirs();

        HikariConfig config = new HikariConfig();
        config.setDriverClassName("org.sqlite.JDBC");
        config.setJdbcUrl("jdbc:sqlite:" + dbFile.getAbsolutePath());
        config.setMaximumPoolSize(1);
        config.setConnectionInitSql("PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL;");
        config.setPoolName("BloodAuth-SQLite");

        dataSource = new HikariDataSource(config);
        createTables();
    }

    @Override
    public void disconnect() {
        executor.shutdown();
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
        }
    }

    @Override
    protected Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    @Override
    protected String upsertKeyword() {
        return "INSERT OR REPLACE";
    }
}
